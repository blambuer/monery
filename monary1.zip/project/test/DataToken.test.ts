import { expect } from "chai";
import { ethers } from "hardhat";
import { DataToken } from "../typechain-types";
import { SignerWithAddress } from "@nomicfoundation/hardhat-ethers/signers";

describe("DataToken", function () {
  let dataToken: DataToken;
  let owner: SignerWithAddress;
  let addr1: SignerWithAddress;
  let addr2: SignerWithAddress;

  beforeEach(async function () {
    [owner, addr1, addr2] = await ethers.getSigners();
    const DataToken = await ethers.getContractFactory("DataToken");
    dataToken = await DataToken.deploy();
  });

  describe("Tokenization", function () {
    it("Should create a new data token", async function () {
      const tx = await dataToken.tokenizeData(
        "QmTest",
        "Test Data",
        "test",
        "Test description"
      );
      await tx.wait();

      const tokenInfo = await dataToken.dataInfo(1);
      expect(tokenInfo.cid).to.equal("QmTest");
      expect(tokenInfo.name).to.equal("Test Data");
      expect(tokenInfo.category).to.equal("test");
      expect(tokenInfo.description).to.equal("Test description");
      expect(tokenInfo.owner).to.equal(await owner.getAddress());
      expect(tokenInfo.isListed).to.equal(false);
      expect(tokenInfo.price).to.equal(0);
    });
  });

  describe("Marketplace", function () {
    beforeEach(async function () {
      await dataToken.tokenizeData(
        "QmTest",
        "Test Data",
        "test",
        "Test description"
      );
    });

    it("Should list a token for sale", async function () {
      const price = ethers.parseEther("1");
      await dataToken.listToken(1, price);
      
      const tokenInfo = await dataToken.dataInfo(1);
      expect(tokenInfo.isListed).to.equal(true);
      expect(tokenInfo.price).to.equal(price);
    });

    it("Should allow buying a listed token", async function () {
      const price = ethers.parseEther("1");
      await dataToken.listToken(1, price);
      
      await dataToken.connect(addr1).buyToken(1, { value: price });
      
      const tokenInfo = await dataToken.dataInfo(1);
      expect(tokenInfo.owner).to.equal(await addr1.getAddress());
      expect(tokenInfo.isListed).to.equal(false);
      expect(tokenInfo.price).to.equal(0);
    });
  });
});