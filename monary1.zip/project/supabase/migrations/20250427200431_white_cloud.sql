/*
  # Fix user_points RLS policies

  1. Changes
    - Drop existing RLS policies for user_points table
    - Add new policies that properly handle:
      - INSERT: Allow authenticated users to create their own records
      - UPDATE: Allow users to update their own records
      - SELECT: Allow public read access
  
  2. Security
    - Enable RLS on user_points table
    - Add policies to ensure users can only manage their own data
    - Maintain public read access for leaderboards and other features
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON public.user_points;
DROP POLICY IF EXISTS "Enable read access for all users" ON public.user_points;
DROP POLICY IF EXISTS "Enable update for users based on wallet_address" ON public.user_points;
DROP POLICY IF EXISTS "Users can read own data" ON public.user_points;
DROP POLICY IF EXISTS "Users can update own data" ON public.user_points;
DROP POLICY IF EXISTS "Users can update their own points" ON public.user_points;
DROP POLICY IF EXISTS "points_select_policy" ON public.user_points;

-- Create new simplified policies
CREATE POLICY "Allow users to create their own records"
ON public.user_points
FOR INSERT
TO authenticated
WITH CHECK (auth.uid()::text = wallet_address);

CREATE POLICY "Allow users to update their own records"
ON public.user_points
FOR UPDATE
TO authenticated
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);

CREATE POLICY "Allow public read access"
ON public.user_points
FOR SELECT
TO public
USING (true);