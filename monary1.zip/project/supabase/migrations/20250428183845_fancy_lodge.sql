/*
  # Add Marketplace Tables

  1. New Tables
    - `marketplace_listings`
      - `id` (uuid, primary key)
      - `token_id` (integer, references data_tokens)
      - `seller` (text, references user_points)
      - `price` (numeric)
      - `is_active` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on marketplace_listings table
    - Add policies for listing management and viewing
*/

-- Create marketplace_listings table
CREATE TABLE marketplace_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_id integer NOT NULL REFERENCES data_tokens(token_id),
  seller text NOT NULL REFERENCES user_points(wallet_address),
  price numeric NOT NULL CHECK (price > 0),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_marketplace_listings_token ON marketplace_listings(token_id);
CREATE INDEX idx_marketplace_listings_seller ON marketplace_listings(seller);
CREATE INDEX idx_marketplace_listings_active ON marketplace_listings(is_active) WHERE is_active = true;

-- Enable RLS
ALTER TABLE marketplace_listings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view active listings"
ON marketplace_listings
FOR SELECT
TO public
USING (is_active = true OR auth.uid()::text = seller);

CREATE POLICY "Users can create their own listings"
ON marketplace_listings
FOR INSERT
TO authenticated
WITH CHECK (auth.uid()::text = seller);

CREATE POLICY "Users can update their own listings"
ON marketplace_listings
FOR UPDATE
TO authenticated
USING (auth.uid()::text = seller)
WITH CHECK (auth.uid()::text = seller);

-- Create updated_at trigger
CREATE TRIGGER update_marketplace_listings_updated_at
  BEFORE UPDATE ON marketplace_listings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();