/*
  # Fix user_points RLS policies

  1. Changes
    - Drop existing RLS policies on user_points table
    - Create new policies that properly handle:
      - Initial user creation without auth
      - Authenticated user updates
      - Public read access
  
  2. Security
    - Enable RLS on user_points table
    - Add policies for:
      - Public insert for new users (both authenticated and unauthenticated)
      - Authenticated users can update their own records
      - Public read access for all records
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "enable_insert_for_new_users" ON "public"."user_points";
DROP POLICY IF EXISTS "enable_public_read" ON "public"."user_points";
DROP POLICY IF EXISTS "enable_update_own_record" ON "public"."user_points";

-- Create new policies with proper permissions
CREATE POLICY "enable_insert_for_new_users"
ON "public"."user_points"
FOR INSERT
TO public
WITH CHECK (
  -- Allow insert if authenticated and wallet_address matches auth user
  (auth.uid() IS NOT NULL AND auth.uid()::text = wallet_address) OR
  -- Or if no auth, allow initial registration
  (auth.uid() IS NULL)
);

CREATE POLICY "enable_public_read"
ON "public"."user_points"
FOR SELECT
TO public
USING (true);

CREATE POLICY "enable_update_own_record"
ON "public"."user_points"
FOR UPDATE
TO public
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);

-- Update handle_new_user function to be more robust
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.user_points (
    wallet_address,
    total_points,
    credit_score,
    network,
    last_login
  )
  VALUES (
    LOWER(new.raw_user_meta_data->>'wallet_address'),
    0,
    500,
    'monad_testnet',
    now()
  )
  ON CONFLICT (wallet_address) 
  DO UPDATE SET
    last_login = now(),
    updated_at = now();
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;