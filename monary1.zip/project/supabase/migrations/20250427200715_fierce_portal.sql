/*
  # Fix user_points RLS policies

  1. Changes
    - Update RLS policies for user_points table to properly handle authentication
    - Add policies for insert and update operations
    - Ensure wallet_address matches authenticated user ID

  2. Security
    - Enable RLS on user_points table
    - Add policies for authenticated users to manage their own records
    - Allow public read access for leaderboard functionality
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can create their own records" ON user_points;
DROP POLICY IF EXISTS "Users can update their own records" ON user_points;
DROP POLICY IF EXISTS "Anyone can view user points" ON user_points;

-- Create new policies
CREATE POLICY "Users can create their own records"
ON user_points
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid()::text = wallet_address
);

CREATE POLICY "Users can update their own records"
ON user_points
FOR UPDATE
TO authenticated
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);

CREATE POLICY "Anyone can view user points"
ON user_points
FOR SELECT
TO public
USING (true);