/*
  # Update authentication schema and triggers

  1. Changes
    - Add trigger to handle new user registration
    - Ensure wallet address is used as user ID
    - Add metadata for wallet address
    
  2. Security
    - Maintain RLS policies
    - Add validation for wallet address format
*/

-- Create a function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.user_points (wallet_address)
  VALUES (new.raw_user_meta_data->>'wallet_address')
  ON CONFLICT (wallet_address) DO NOTHING;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger to automatically create user_points entry
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();