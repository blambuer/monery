/*
  # Data Tokens Schema

  1. New Tables
    - `data_tokens`
      - `id` (uuid, primary key)
      - `token_id` (integer, unique)
      - `wallet_address` (text, foreign key)
      - `cid` (text)
      - `name` (text)
      - `category` (text)
      - `description` (text)
      - `price` (numeric)
      - `is_listed` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `data_tokens` table
    - Add policies for authenticated users to manage their own tokens
    - Allow public read access for listed tokens
*/

-- Create data_tokens table
CREATE TABLE IF NOT EXISTS data_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_id integer UNIQUE NOT NULL,
  wallet_address text NOT NULL REFERENCES user_points(wallet_address),
  cid text NOT NULL,
  name text NOT NULL,
  category text NOT NULL,
  description text,
  price numeric DEFAULT 0,
  is_listed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_data_tokens_wallet ON data_tokens(wallet_address);
CREATE INDEX IF NOT EXISTS idx_data_tokens_category ON data_tokens(category);
CREATE INDEX IF NOT EXISTS idx_data_tokens_listed ON data_tokens(is_listed) WHERE is_listed = true;

-- Enable RLS
ALTER TABLE data_tokens ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view listed tokens"
ON data_tokens
FOR SELECT
TO public
USING (is_listed = true OR auth.uid()::text = wallet_address);

CREATE POLICY "Users can manage their own tokens"
ON data_tokens
FOR ALL
TO authenticated
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_data_tokens_updated_at
  BEFORE UPDATE ON data_tokens
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();