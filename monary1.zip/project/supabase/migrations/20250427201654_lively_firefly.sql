/*
  # Fix RLS policies and user creation

  1. Changes
    - Simplify RLS policies
    - Fix user creation flow
    - Add proper authentication checks

  2. Security
    - Enable RLS
    - Add policies for authenticated users
    - Allow public read access
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can create their own records" ON user_points;
DROP POLICY IF EXISTS "Users can update their own records" ON user_points;
DROP POLICY IF EXISTS "Anyone can view user points" ON user_points;

-- Create new simplified policies
CREATE POLICY "enable_read_access"
ON user_points
FOR SELECT
TO public
USING (true);

CREATE POLICY "enable_insert_for_auth"
ON user_points
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid()::text = wallet_address
);

CREATE POLICY "enable_update_for_auth"
ON user_points
FOR UPDATE
TO authenticated
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);

-- Update the handle_new_user function to be more robust
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.user_points (
    wallet_address,
    total_points,
    credit_score
  )
  VALUES (
    LOWER(new.raw_user_meta_data->>'wallet_address'),
    0,
    500
  )
  ON CONFLICT (wallet_address) 
  DO UPDATE SET
    updated_at = now()
  WHERE user_points.wallet_address = LOWER(new.raw_user_meta_data->>'wallet_address');
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;