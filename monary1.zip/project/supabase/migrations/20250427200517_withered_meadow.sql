/*
  # Update user_points table RLS policies

  1. Changes
    - Add policy for inserting new user records
    - Update existing policies to handle both authenticated and public access properly
    
  2. Security
    - Enable RLS on user_points table (already enabled)
    - Add policy for new user creation
    - Maintain existing policies for updates and reads
*/

-- Drop existing policies to recreate them with proper permissions
DROP POLICY IF EXISTS "Allow public read access" ON public.user_points;
DROP POLICY IF EXISTS "Allow users to create their own records" ON public.user_points;
DROP POLICY IF EXISTS "Allow users to update their own records" ON public.user_points;
DROP POLICY IF EXISTS "Anyone can view user points" ON public.user_points;

-- Create new policies with proper permissions
CREATE POLICY "Anyone can view user points"
ON public.user_points
FOR SELECT
TO public
USING (true);

CREATE POLICY "Users can create their own records"
ON public.user_points
FOR INSERT
TO public
WITH CHECK (
  -- Allow creation for authenticated users matching their wallet
  (auth.uid() IS NOT NULL AND auth.uid()::text = wallet_address) OR
  -- Also allow initial creation during signup
  (auth.uid() IS NULL)
);

CREATE POLICY "Users can update their own records"
ON public.user_points
FOR UPDATE
TO authenticated
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);