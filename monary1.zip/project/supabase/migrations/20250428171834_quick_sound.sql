/*
  # Add wallet signatures and network info

  1. New Columns
    - Add auth_signature for storing authentication signatures
    - Add approval_signature for storing platform approval
    - Add network column to track which network the wallet is using
    - Add last_login timestamp

  2. Changes
    - Update existing user_points table with new columns
    - Add indexes for better query performance
*/

-- Add new columns to user_points table
ALTER TABLE user_points
ADD COLUMN IF NOT EXISTS auth_signature text,
ADD COLUMN IF NOT EXISTS approval_signature text,
ADD COLUMN IF NOT EXISTS network text DEFAULT 'monad_testnet',
ADD COLUMN IF NOT EXISTS last_login timestamptz;

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_user_points_network ON user_points(network);
CREATE INDEX IF NOT EXISTS idx_user_points_last_login ON user_points(last_login DESC);

-- Update handle_new_user function to include new fields
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.user_points (
    wallet_address,
    total_points,
    credit_score,
    network,
    auth_signature,
    approval_signature,
    last_login
  )
  VALUES (
    LOWER(new.raw_user_meta_data->>'wallet_address'),
    0,
    500,
    'monad_testnet',
    new.raw_user_meta_data->>'auth_signature',
    new.raw_user_meta_data->>'approval_signature',
    now()
  )
  ON CONFLICT (wallet_address) 
  DO UPDATE SET
    auth_signature = EXCLUDED.auth_signature,
    approval_signature = EXCLUDED.approval_signature,
    last_login = now(),
    updated_at = now()
  WHERE user_points.wallet_address = LOWER(new.raw_user_meta_data->>'wallet_address');
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;