/*
  # Fix user_points RLS policies

  1. Changes
    - Drop existing RLS policies for user_points table
    - Create new policies that properly handle:
      - Public insert for new users
      - Authenticated user updates
      - Public read access
  
  2. Security
    - Enable RLS on user_points table
    - Add policies for:
      - Insert: Allow public insert for new users
      - Update: Only allow users to update their own records
      - Select: Allow public read access
*/

-- Drop existing policies
DROP POLICY IF EXISTS "enable_auth_update" ON "public"."user_points";
DROP POLICY IF EXISTS "enable_public_insert" ON "public"."user_points";
DROP POLICY IF EXISTS "enable_public_read" ON "public"."user_points";

-- Create new policies
CREATE POLICY "enable_insert_for_new_users"
ON "public"."user_points"
FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "enable_update_own_record"
ON "public"."user_points"
FOR UPDATE
TO public
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);

CREATE POLICY "enable_public_read"
ON "public"."user_points"
FOR SELECT
TO public
USING (true);