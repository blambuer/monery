/*
  # Fix RLS policies for user_points table
  
  1. Changes
    - Drop existing policies
    - Create new simplified policies that allow:
      - Public read access
      - Public insert during signup
      - Authenticated updates for own records
    
  2. Security
    - Maintains data privacy while allowing initial user creation
    - Ensures users can only modify their own data
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can insert during signup" ON public.user_points;
DROP POLICY IF EXISTS "Users can read all user points" ON public.user_points;
DROP POLICY IF EXISTS "Users can update their own records" ON public.user_points;

-- Create new policies with proper permissions
CREATE POLICY "enable_public_read"
ON public.user_points
FOR SELECT 
TO public
USING (true);

CREATE POLICY "enable_public_insert"
ON public.user_points
FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "enable_auth_update"
ON public.user_points
FOR UPDATE
TO public
USING (
  wallet_address = current_setting('request.jwt.claims', true)::json->>'wallet_address'
)
WITH CHECK (
  wallet_address = current_setting('request.jwt.claims', true)::json->>'wallet_address'
);

-- Update handle_new_user function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.user_points (
    wallet_address,
    total_points,
    credit_score,
    network,
    auth_signature,
    last_login
  )
  VALUES (
    LOWER(new.raw_user_meta_data->>'wallet_address'),
    0,
    500,
    'monad_testnet',
    new.raw_user_meta_data->>'auth_signature',
    now()
  )
  ON CONFLICT (wallet_address) 
  DO UPDATE SET
    auth_signature = EXCLUDED.auth_signature,
    last_login = now(),
    updated_at = now();
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;