/*
  # Create user points table

  1. New Tables
    - `user_points`
      - `id` (uuid, primary key)
      - `wallet_address` (text, unique)
      - `total_points` (integer)
      - `credit_score` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `user_points` table
    - Add policies for authenticated users to read/write their own data
*/

CREATE TABLE IF NOT EXISTS user_points (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_address text UNIQUE NOT NULL,
  total_points integer DEFAULT 0,
  credit_score integer DEFAULT 500,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_points ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON user_points
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = wallet_address);

CREATE POLICY "Users can insert own data"
  ON user_points
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = wallet_address);

CREATE POLICY "Users can update own data"
  ON user_points
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = wallet_address);