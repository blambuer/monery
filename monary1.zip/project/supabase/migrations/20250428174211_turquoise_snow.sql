/*
  # Fix user_points RLS policies

  1. Changes
    - Drop existing RLS policies on user_points table
    - Create new policies that properly handle:
      - New user registration
      - User updates to their own records
      - Public read access
  
  2. Security
    - Enable RLS on user_points table
    - Add policies for:
      - Public insert for new users
      - Users can update their own records
      - Anyone can view points (public read)
*/

-- Drop existing policies
DROP POLICY IF EXISTS "enable_insert_for_new_users" ON "public"."user_points";
DROP POLICY IF EXISTS "enable_public_read" ON "public"."user_points";
DROP POLICY IF EXISTS "enable_update_own_record" ON "public"."user_points";

-- Create new policies
CREATE POLICY "enable_insert_for_new_users"
ON "public"."user_points"
FOR INSERT
TO public
WITH CHECK (
  -- Allow insert if authenticated and wallet_address matches auth user
  (auth.uid() IS NOT NULL AND auth.uid()::text = wallet_address) OR
  -- Or if no auth, allow initial registration
  (auth.uid() IS NULL)
);

CREATE POLICY "enable_public_read"
ON "public"."user_points"
FOR SELECT
TO public
USING (true);

CREATE POLICY "enable_update_own_record"
ON "public"."user_points"
FOR UPDATE
TO public
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);