/*
  # Fix RLS policies for user_points table

  1. Changes
    - Drop existing conflicting RLS policies
    - Add new policies that properly handle:
      - User creation for authenticated users
      - Updates for authenticated users
      - Public read access
  
  2. Security
    - Enable RLS
    - Add policies for:
      - INSERT: Allow authenticated users to create their own records
      - UPDATE: Allow authenticated users to update their own records
      - SELECT: Allow public read access
*/

-- Drop existing conflicting policies
DROP POLICY IF EXISTS "Users can insert own data" ON public.user_points;
DROP POLICY IF EXISTS "Users can insert their points" ON public.user_points;
DROP POLICY IF EXISTS "points_insert_policy" ON public.user_points;
DROP POLICY IF EXISTS "points_update_policy" ON public.user_points;

-- Create new policies
CREATE POLICY "Enable insert for authenticated users only"
ON public.user_points
FOR INSERT
TO authenticated
WITH CHECK (auth.uid()::text = wallet_address);

CREATE POLICY "Enable update for users based on wallet_address"
ON public.user_points
FOR UPDATE
TO authenticated
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);

CREATE POLICY "Enable read access for all users"
ON public.user_points
FOR SELECT
TO public
USING (true);

-- Keep the table RLS enabled
ALTER TABLE public.user_points ENABLE ROW LEVEL SECURITY;