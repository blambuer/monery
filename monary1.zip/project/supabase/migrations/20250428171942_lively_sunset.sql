/*
  # Fix RLS policies for user_points table

  1. Changes
    - Update RLS policies for user_points table to allow proper wallet connection
    - Add policy for unauthenticated users to insert during signup
    - Add policy for authenticated users to update their own records
    - Add policy for public read access to user points data

  2. Security
    - Maintains data security by ensuring users can only modify their own records
    - Allows initial user creation during wallet connection
    - Preserves public read access for leaderboards and other features
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "enable_insert_for_auth" ON "public"."user_points";
DROP POLICY IF EXISTS "enable_read_access" ON "public"."user_points";
DROP POLICY IF EXISTS "enable_update_for_auth" ON "public"."user_points";

-- Create new policies with proper permissions
CREATE POLICY "Anyone can insert during signup"
ON "public"."user_points"
FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "Users can read all user points"
ON "public"."user_points"
FOR SELECT
TO public
USING (true);

CREATE POLICY "Users can update their own records"
ON "public"."user_points"
FOR UPDATE
TO public
USING (auth.uid()::text = wallet_address)
WITH CHECK (auth.uid()::text = wallet_address);