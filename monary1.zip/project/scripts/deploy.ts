import { ethers } from "hardhat";

async function main() {
  console.log("Deploying DataToken contract...");

  const DataToken = await ethers.getContractFactory("DataToken");
  const dataToken = await DataToken.deploy();
  await dataToken.waitForDeployment();

  const address = await dataToken.getAddress();
  console.log("DataToken deployed to:", address);

  // Update the contract address in the frontend
  const fs = require('fs');
  const path = require('path');
  
  const contractConfigPath = path.join(__dirname, '../src/lib/contracts/DataTokenContract.ts');
  let content = fs.readFileSync(contractConfigPath, 'utf8');
  
  content = content.replace(
    /export const DataTokenAddress = ".*"/,
    `export const DataTokenAddress = "${address}"`
  );
  
  fs.writeFileSync(contractConfigPath, content);
  console.log("Contract address updated in frontend configuration");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });