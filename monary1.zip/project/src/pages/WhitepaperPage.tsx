import React, { useEffect } from 'react';
import Section from '../components/ui/Section';
import Animated from '../components/ui/Animated';
import { Download } from 'lucide-react';
import Button from '../components/ui/Button';

const WhitepaperPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Monery Whitepaper - Technical Documentation';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Monery Whitepaper
            </h1>
            <p className="text-lg text-white/80 mb-8">
              A Decentralized Data Monetization Protocol
            </p>
            <Button variant="accent" size="lg">
              <Download className="h-5 w-5 mr-2" />
              Download PDF Version
            </Button>
          </Animated>
        </div>
      </Section>

      <Section background="white" className="py-20">
        <div className="max-w-4xl mx-auto prose">
          <Animated type="slide-up">
            <h2>Abstract</h2>
            <p>
              Monery introduces a revolutionary blockchain-based protocol that enables individuals to 
              tokenize, manage, and monetize their personal data while maintaining complete privacy 
              and control. By leveraging zero-knowledge proofs, homomorphic encryption, and AI-driven 
              analytics, Monery creates a secure and efficient marketplace for data assets.
            </p>

            <h2>1. Introduction</h2>
            <p>
              The digital economy has created an unprecedented accumulation of personal data, yet 
              individuals who generate this data receive no direct economic benefit. Monery addresses 
              this imbalance by creating a decentralized protocol that enables:
            </p>
            <ul>
              <li>Secure data tokenization and ownership verification</li>
              <li>Privacy-preserving data trading mechanisms</li>
              <li>Fair value distribution to data creators</li>
              <li>AI-powered price discovery and market optimization</li>
            </ul>

            <h2>2. Technical Architecture</h2>
            
            <h3>2.1 Protocol Stack</h3>
            <div className="bg-gray-50 p-6 rounded-xl mb-8">
              <img 
                src="https://images.pexels.com/photos/8370764/pexels-photo-8370764.jpeg" 
                alt="Protocol Stack Diagram"
                className="rounded-lg mb-4"
              />
              <p className="text-sm text-gray-600 text-center">
                Figure 1: Monery Protocol Stack Architecture
              </p>
            </div>

            <h3>2.2 Data Tokenization Process</h3>
            <p>
              The tokenization process involves several cryptographic steps:
            </p>
            <ol>
              <li>Data encryption using AES-256</li>
              <li>Metadata extraction and classification</li>
              <li>Zero-knowledge proof generation</li>
              <li>Smart contract deployment</li>
            </ol>

            <div className="bg-gray-50 p-6 rounded-xl mb-8">
              <img 
                src="https://images.pexels.com/photos/8370602/pexels-photo-8370602.jpeg" 
                alt="Tokenization Flow"
                className="rounded-lg mb-4"
              />
              <p className="text-sm text-gray-600 text-center">
                Figure 2: Data Tokenization Flow
              </p>
            </div>

            <h2>3. Tokenomics</h2>
            
            <h3>3.1 MON Token Utility</h3>
            <p>
              The MON token serves multiple purposes within the ecosystem:
            </p>
            <ul>
              <li>Governance rights</li>
              <li>Transaction fee payments</li>
              <li>Staking rewards</li>
              <li>Data marketplace currency</li>
            </ul>

            <h3>3.2 Token Distribution</h3>
            <div className="bg-gray-50 p-6 rounded-xl mb-8">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-lg font-semibold mb-2">Initial Distribution</h4>
                  <ul>
                    <li>Community: 40%</li>
                    <li>Development: 25%</li>
                    <li>Team: 15%</li>
                    <li>Treasury: 10%</li>
                    <li>Advisors: 5%</li>
                    <li>Marketing: 5%</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-2">Vesting Schedule</h4>
                  <ul>
                    <li>Team: 4-year vesting, 1-year cliff</li>
                    <li>Advisors: 2-year vesting</li>
                    <li>Development: Linear release over 5 years</li>
                  </ul>
                </div>
              </div>
            </div>

            <h3>3.3 Economic Model</h3>
            <p>
              The Monery economic model is designed to create sustainable value growth through:
            </p>
            <div className="bg-gray-50 p-6 rounded-xl mb-8">
              <pre className="text-sm overflow-x-auto">
                {`Token Value = (Network Activity × Data Quality) / Token Supply

Where:
- Network Activity = Daily Active Users × Transaction Volume
- Data Quality = Average Data Score × Verification Rate
- Token Supply = Circulating Supply × (1 - Staked Percentage)`}
              </pre>
            </div>

            <h2>4. Privacy Technology</h2>
            
            <h3>4.1 Zero-Knowledge Architecture</h3>
            <p>
              Monery implements a sophisticated zero-knowledge proof system that enables:
            </p>
            <ul>
              <li>Data verification without exposure</li>
              <li>Anonymous transactions</li>
              <li>Private metadata matching</li>
            </ul>

            <div className="bg-gray-50 p-6 rounded-xl mb-8">
              <img 
                src="https://images.pexels.com/photos/8370776/pexels-photo-8370776.jpeg" 
                alt="Privacy Architecture"
                className="rounded-lg mb-4"
              />
              <p className="text-sm text-gray-600 text-center">
                Figure 3: Zero-Knowledge Privacy Architecture
              </p>
            </div>

            <h2>5. AI Integration</h2>
            
            <h3>5.1 Market Intelligence</h3>
            <p>
              The platform employs advanced AI models for:
            </p>
            <ul>
              <li>Price prediction and optimization</li>
              <li>Data quality assessment</li>
              <li>Market trend analysis</li>
              <li>Fraud detection</li>
            </ul>

            <div className="bg-gray-50 p-6 rounded-xl mb-8">
              <pre className="text-sm overflow-x-auto">
                {`Price Optimization Formula:

P(t) = β₁V(t) + β₂Q(t) + β₃D(t) + β₄S(t)

Where:
P(t) = Optimal price at time t
V(t) = Market volume factor
Q(t) = Quality score
D(t) = Demand index
S(t) = Scarcity factor
β₁-β₄ = Weight coefficients`}
              </pre>
            </div>

            <h2>6. Governance</h2>
            
            <h3>6.1 DAO Structure</h3>
            <p>
              Monery implements a decentralized governance model where:
            </p>
            <ul>
              <li>Token holders can propose and vote on protocol changes</li>
              <li>Staking increases voting power</li>
              <li>Multi-sig treasury management</li>
            </ul>

            <h3>6.2 Proposal Process</h3>
            <div className="bg-gray-50 p-6 rounded-xl mb-8">
              <ol>
                <li>Proposal submission (requires 1% token stake)</li>
                <li>7-day discussion period</li>
                <li>3-day voting period</li>
                <li>2-day timelock for implementation</li>
              </ol>
            </div>

            <h2>7. Roadmap</h2>
            
            <h3>7.1 Development Phases</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold">Phase 1: Foundation (Q1-Q2 2024)</h4>
                <ul>
                  <li>Core protocol development</li>
                  <li>Privacy infrastructure implementation</li>
                  <li>Basic marketplace features</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold">Phase 2: Expansion (Q3-Q4 2024)</h4>
                <ul>
                  <li>AI integration</li>
                  <li>Advanced trading features</li>
                  <li>Mobile app launch</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold">Phase 3: Ecosystem (Q1-Q2 2025)</h4>
                <ul>
                  <li>Developer SDK release</li>
                  <li>Partnership program</li>
                  <li>Cross-chain integration</li>
                </ul>
              </div>
            </div>

            <h2>8. Security Considerations</h2>
            
            <h3>8.1 Threat Model</h3>
            <p>
              The protocol's security model addresses:
            </p>
            <ul>
              <li>Data privacy breaches</li>
              <li>Smart contract vulnerabilities</li>
              <li>Economic attack vectors</li>
              <li>Network security</li>
            </ul>

            <h3>8.2 Audit Process</h3>
            <div className="bg-gray-50 p-6 rounded-xl mb-8">
              <ul>
                <li>Regular third-party security audits</li>
                <li>Continuous vulnerability scanning</li>
                <li>Bug bounty program</li>
                <li>Incident response plan</li>
              </ul>
            </div>

            <h2>9. Conclusion</h2>
            <p>
              Monery represents a paradigm shift in personal data monetization, combining 
              cutting-edge cryptography, AI, and blockchain technology to create a secure, 
              efficient, and user-centric data economy. Through its innovative approach to 
              privacy and value creation, Monery aims to democratize data ownership and 
              establish a new standard for digital asset management.
            </p>

            <div className="mt-12 p-8 bg-gray-50 rounded-xl">
              <h3>References</h3>
              <ol className="space-y-2">
                <li>
                  "Zero-Knowledge Proofs in Blockchain Applications" - Cryptography Journal, 2023
                </li>
                <li>
                  "AI-Driven Market Making in Decentralized Exchanges" - DeFi Research Quarterly, 2024
                </li>
                <li>
                  "Privacy-Preserving Data Markets" - Journal of Blockchain Economics, 2024
                </li>
                <li>
                  "Tokenomics Design Patterns" - Cryptocurrency Economics Review, 2023
                </li>
              </ol>
            </div>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default WhitepaperPage;