import React, { useEffect } from 'react';
import Section from '../components/ui/Section';
import Animated from '../components/ui/Animated';
import { Users, Target, Zap, Globe } from 'lucide-react';

const AboutPage: React.FC = () => {
  useEffect(() => {
    document.title = 'About Monery - Our Mission & Vision';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About Monery
            </h1>
            <p className="text-lg text-white/80">
              Monery is revolutionizing the way individuals own, control, and monetize their personal data. 
              Built on the principles of privacy, transparency, and user empowerment, we're creating a 
              future where data ownership benefits everyone.
            </p>
          </Animated>
        </div>
      </Section>

      <Section background="light" className="py-20">
        <div className="max-w-3xl mx-auto">
          <Animated type="slide-up">
            <h2 className="text-3xl font-bold mb-6">Our Story</h2>
            <p className="text-lg text-text-secondary mb-8">
              Founded in 2024, Monery emerged from a simple yet powerful idea: what if people could 
              actually profit from their own digital footprint? We saw how big tech companies were 
              making billions from user data, while those same users received nothing in return.
            </p>
            <p className="text-lg text-text-secondary mb-8">
              Our team of blockchain developers, privacy experts, and data scientists came together 
              to build a platform that puts users first. By combining zero-knowledge proofs, 
              blockchain technology, and artificial intelligence, we've created a secure and 
              transparent way for individuals to monetize their data while maintaining complete 
              privacy.
            </p>
          </Animated>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
            <Animated type="fade" delay={0.1}>
              <div className="bg-white p-6 rounded-xl shadow-md">
                <Globe className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">Global Impact</h3>
                <p className="text-text-secondary">
                  Operating in over 30 countries, Monery is helping thousands of users take control 
                  of their digital identity and earn from their data.
                </p>
              </div>
            </Animated>

            <Animated type="fade" delay={0.2}>
              <div className="bg-white p-6 rounded-xl shadow-md">
                <Target className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">Our Values</h3>
                <p className="text-text-secondary">
                  Privacy, transparency, and user empowerment are at the core of everything we do. 
                  We believe in creating technology that serves people, not the other way around.
                </p>
              </div>
            </Animated>
          </div>
        </div>
      </Section>

      <Section background="dark" className="py-20">
        <div className="max-w-3xl mx-auto">
          <Animated type="slide-up">
            <h2 className="text-3xl font-bold text-white mb-12">Leadership Team</h2>
          </Animated>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Animated type="fade" delay={0.1}>
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl text-white">
                <img 
                  src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg" 
                  alt="CEO" 
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-center">Alex Thompson</h3>
                <p className="text-white/80 text-center">CEO & Co-founder</p>
              </div>
            </Animated>

            <Animated type="fade" delay={0.2}>
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl text-white">
                <img 
                  src="https://images.pexels.com/photos/3778876/pexels-photo-3778876.jpeg" 
                  alt="CTO" 
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-center">Sarah Chen</h3>
                <p className="text-white/80 text-center">CTO</p>
              </div>
            </Animated>

            <Animated type="fade" delay={0.3}>
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl text-white">
                <img 
                  src="https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg" 
                  alt="Head of Research" 
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-bold text-center">Dr. Marcus Kim</h3>
                <p className="text-white/80 text-center">Head of Research</p>
              </div>
            </Animated>
          </div>
        </div>
      </Section>

      <Section background="light" className="py-20">
        <div className="max-w-3xl mx-auto">
          <Animated type="slide-up">
            <h2 className="text-3xl font-bold mb-12">Join Our Mission</h2>
            <p className="text-lg text-text-secondary mb-8">
              We're always looking for talented individuals who share our vision of a more equitable 
              digital economy. If you're passionate about blockchain, privacy, or data rights, we'd 
              love to hear from you.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <a 
                href="mailto:careers@monery.xyz" 
                className="bg-primary text-white p-6 rounded-xl text-center hover:bg-primary-dark transition-colors"
              >
                <Users className="h-8 w-8 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Open Positions</h3>
                <p>View our current job openings</p>
              </a>
              <a 
                href="mailto:partnerships@monery.xyz" 
                className="bg-secondary text-white p-6 rounded-xl text-center hover:bg-secondary-dark transition-colors"
              >
                <Zap className="h-8 w-8 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Partnerships</h3>
                <p>Explore collaboration opportunities</p>
              </a>
            </div>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default AboutPage;