import React, { useEffect } from 'react';
import Section from '../components/ui/Section';
import Animated from '../components/ui/Animated';

const TermsPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Monery Terms of Service';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Terms of Service
            </h1>
            <p className="text-lg text-white/80">
              Last updated: March 15, 2024
            </p>
          </Animated>
        </div>
      </Section>

      <Section background="white" className="py-20">
        <div className="max-w-3xl mx-auto prose">
          <Animated type="slide-up">
            <h2>1. Agreement to Terms</h2>
            <p>
              By accessing or using Monery's platform, you agree to be bound by these Terms of 
              Service and all applicable laws and regulations.
            </p>

            <h2>2. Description of Services</h2>
            <p>
              Monery provides a platform for:
            </p>
            <ul>
              <li>Data tokenization and management</li>
              <li>Marketplace for buying and selling tokenized data</li>
              <li>Data privacy and security tools</li>
              <li>Analytics and reporting features</li>
            </ul>

            <h2>3. User Accounts</h2>
            <p>
              To use our services, you must:
            </p>
            <ul>
              <li>Be at least 18 years old</li>
              <li>Provide accurate and complete information</li>
              <li>Maintain the security of your account</li>
              <li>Accept responsibility for all activities under your account</li>
            </ul>

            <h2>4. User Responsibilities</h2>
            <p>You agree to:</p>
            <ul>
              <li>Use the platform legally and ethically</li>
              <li>Not violate others' privacy or intellectual property rights</li>
              <li>Not engage in fraudulent or deceptive practices</li>
              <li>Not attempt to circumvent platform security</li>
            </ul>

            <h2>5. Data Rights and Ownership</h2>
            <p>
              Users retain ownership of their data while granting Monery limited rights to:
            </p>
            <ul>
              <li>Process and store data for service provision</li>
              <li>Facilitate marketplace transactions</li>
              <li>Generate anonymous analytics</li>
            </ul>

            <h2>6. Fees and Payments</h2>
            <p>
              Platform fees include:
            </p>
            <ul>
              <li>Transaction fees (5% of sale price)</li>
              <li>Gas fees for blockchain operations</li>
              <li>Optional premium features</li>
            </ul>

            <h2>7. Intellectual Property</h2>
            <p>
              All platform content, features, and functionality are owned by Monery and protected 
              by intellectual property laws.
            </p>

            <h2>8. Limitation of Liability</h2>
            <p>
              Monery is not liable for:
            </p>
            <ul>
              <li>Data loss or corruption</li>
              <li>Service interruptions</li>
              <li>Third-party actions</li>
              <li>Indirect or consequential damages</li>
            </ul>

            <h2>9. Dispute Resolution</h2>
            <p>
              Any disputes will be resolved through:
            </p>
            <ul>
              <li>Initial informal negotiation</li>
              <li>Mediation if necessary</li>
              <li>Binding arbitration as a last resort</li>
            </ul>

            <h2>10. Termination</h2>
            <p>
              We may terminate or suspend your account for:
            </p>
            <ul>
              <li>Terms of Service violations</li>
              <li>Fraudulent activity</li>
              <li>Extended inactivity</li>
              <li>At our discretion with notice</li>
            </ul>

            <h2>11. Changes to Terms</h2>
            <p>
              We may modify these terms at any time. Continued use of the platform constitutes 
              acceptance of modified terms.
            </p>

            <h2>12. Contact Information</h2>
            <p>
              For questions about these Terms, contact us at:
              <br />
              Email: legal@monery.xyz
              <br />
              Address: 123 Blockchain Street, San Francisco, CA 94105
            </p>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default TermsPage;