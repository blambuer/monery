import React, { useEffect } from 'react';
import Section from '../components/ui/Section';
import UserProgress from '../components/profile/UserProgress';
import ReferralSystem from '../components/profile/ReferralSystem';
import Achievements from '../components/profile/Achievements';
import Animated from '../components/ui/Animated';

const ProfilePage: React.FC = () => {
  useEffect(() => {
    document.title = 'Monery - Your Profile';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-4xl mx-auto">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Your Profile
            </h1>
            <p className="text-lg text-white/80">
              Track your progress, achievements, and referral rewards.
            </p>
          </Animated>
        </div>
      </Section>

      <Section background="light" className="py-20">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Animated type="slide-up">
                <h2 className="text-2xl font-bold mb-6">Progress</h2>
                <UserProgress />
              </Animated>
              
              <Animated type="slide-up" delay={0.1}>
                <h2 className="text-2xl font-bold mb-6 mt-12">Achievements</h2>
                <Achievements />
              </Animated>
            </div>
            
            <div>
              <Animated type="slide-up" delay={0.2}>
                <h2 className="text-2xl font-bold mb-6">Referrals</h2>
                <ReferralSystem />
              </Animated>
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
};

export default ProfilePage;