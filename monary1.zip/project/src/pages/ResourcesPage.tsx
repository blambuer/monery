import React, { useEffect } from 'react';
import Section from '../components/ui/Section';
import Animated from '../components/ui/Animated';
import { Book, FileText, Video, Download } from 'lucide-react';

const ResourcesPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Monery Resources - Guides & Documentation';
    window.scrollTo(0, 0);
  }, []);

  const resources = {
    guides: [
      {
        title: 'Getting Started with Monery',
        description: 'Learn the basics of data monetization and how to use the Monery platform.',
        link: '/docs/getting-started'
      },
      {
        title: 'Data Tokenization Guide',
        description: 'Understand how to tokenize different types of data and set optimal prices.',
        link: '/docs/tokenization'
      },
      {
        title: 'Privacy & Security Best Practices',
        description: 'Essential security tips for protecting your data and maximizing earnings.',
        link: '/docs/security'
      }
    ],
    documentation: [
      {
        title: 'API Documentation',
        description: 'Complete reference for the Monery API and integration guides.',
        link: '/docs/api'
      },
      {
        title: 'Smart Contract Reference',
        description: 'Technical documentation for Monery\'s blockchain infrastructure.',
        link: '/docs/contracts'
      },
      {
        title: 'SDK Documentation',
        description: 'Guides and references for the Monery SDK.',
        link: '/docs/sdk'
      }
    ],
    tutorials: [
      {
        title: 'Setting Up Your First Data Token',
        description: 'Step-by-step video guide to tokenizing your first data set.',
        link: '/tutorials/first-token'
      },
      {
        title: 'Maximizing Your Earnings',
        description: 'Advanced strategies for data monetization.',
        link: '/tutorials/optimization'
      },
      {
        title: 'Using the Marketplace',
        description: 'Learn how to effectively list and sell your data.',
        link: '/tutorials/marketplace'
      }
    ]
  };

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Resources
            </h1>
            <p className="text-lg text-white/80">
              Everything you need to succeed with Monery. Browse our comprehensive guides, 
              documentation, and tutorials.
            </p>
          </Animated>
        </div>
      </Section>

      <Section background="light" className="py-20">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Animated type="fade" delay={0.1}>
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <div className="bg-primary/10 p-4 rounded-full inline-flex mb-6">
                  <Book className="h-8 w-8 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-6">User Guides</h2>
                <div className="space-y-4">
                  {resources.guides.map((guide, index) => (
                    <a
                      key={index}
                      href={guide.link}
                      className="block p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <h3 className="font-semibold mb-1">{guide.title}</h3>
                      <p className="text-sm text-text-secondary">{guide.description}</p>
                    </a>
                  ))}
                </div>
              </div>
            </Animated>

            <Animated type="fade" delay={0.2}>
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <div className="bg-primary/10 p-4 rounded-full inline-flex mb-6">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-6">Documentation</h2>
                <div className="space-y-4">
                  {resources.documentation.map((doc, index) => (
                    <a
                      key={index}
                      href={doc.link}
                      className="block p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <h3 className="font-semibold mb-1">{doc.title}</h3>
                      <p className="text-sm text-text-secondary">{doc.description}</p>
                    </a>
                  ))}
                </div>
              </div>
            </Animated>

            <Animated type="fade" delay={0.3}>
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <div className="bg-primary/10 p-4 rounded-full inline-flex mb-6">
                  <Video className="h-8 w-8 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-6">Video Tutorials</h2>
                <div className="space-y-4">
                  {resources.tutorials.map((tutorial, index) => (
                    <a
                      key={index}
                      href={tutorial.link}
                      className="block p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <h3 className="font-semibold mb-1">{tutorial.title}</h3>
                      <p className="text-sm text-text-secondary">{tutorial.description}</p>
                    </a>
                  ))}
                </div>
              </div>
            </Animated>
          </div>
        </div>
      </Section>

      <Section background="white" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h2 className="text-3xl font-bold mb-6">Developer Resources</h2>
            <p className="text-text-secondary mb-12">
              Access everything you need to build with Monery.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <a
                href="/docs/sdk-download"
                className="flex items-center justify-center p-6 bg-primary text-white rounded-xl hover:bg-primary-dark transition-colors"
              >
                <Download className="h-6 w-6 mr-3" />
                <span className="font-semibold">Download SDK</span>
              </a>
              <a
                href="https://github.com/monery"
                className="flex items-center justify-center p-6 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition-colors"
              >
                <svg
                  className="h-6 w-6 mr-3"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 21.795 24 17.295 24 12c0-6.63-5.37-12-12-12" />
                </svg>
                <span className="font-semibold">View on GitHub</span>
              </a>
            </div>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default ResourcesPage;