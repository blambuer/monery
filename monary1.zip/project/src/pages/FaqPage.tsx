import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp, Search } from 'lucide-react';
import Section from '../components/ui/Section';
import Button from '../components/ui/Button';
import Animated from '../components/ui/Animated';

const FaqPage: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  useEffect(() => {
    document.title = 'Monery FAQ - Frequently Asked Questions';
    window.scrollTo(0, 0);
  }, []);

  const faqs = [
    {
      category: 'general',
      question: 'What is Monery and how does it help me earn?',
      answer: 'Monery is a platform that enables you to collect, tokenize, and monetize your personal data while maintaining complete privacy and control. It transforms your digital footprint into valuable assets that can generate income through our marketplace.'
    },
    {
      category: 'privacy',
      question: 'Is my data visible to others?',
      answer: 'No. All your data is encrypted and stored securely. Only the specific data you choose to sell or share is made available to buyers, and even then, it\'s anonymized using zero-knowledge technology to protect your identity.'
    },
    {
      category: 'marketplace',
      question: 'Who can purchase my tokenized data?',
      answer: 'Researchers, advertisers, AI development projects, and data analytics firms can request data through our secure marketplace. All buyers are verified and must adhere to strict usage guidelines to ensure ethical data practices.'
    },
    {
      category: 'technical',
      question: 'Which blockchain does Monery use?',
      answer: 'Monery is built on the Monad blockchain, which offers high-speed transactions with minimal fees. This ensures a seamless experience when tokenizing data assets and receiving payments.'
    },
    {
      category: 'general',
      question: 'Is using Monery free?',
      answer: 'Downloading and using the Monery app is completely free. We only take a small platform fee from successful data sales. There are no hidden costs or subscription fees.'
    },
    {
      category: 'technical',
      question: 'How does the tokenization process work?',
      answer: 'When you tokenize data, our platform converts your selected digital information into encrypted, tradable assets on the blockchain. These tokens represent ownership of specific data sets without revealing the underlying content.'
    },
    {
      category: 'marketplace',
      question: 'How much can I earn with Monery?',
      answer: 'Earnings vary based on the type, quantity, and quality of data you provide. Some users earn a few dollars monthly, while power users with valuable data sets can earn hundreds or even thousands of dollars.'
    },
    {
      category: 'general',
      question: 'How do I withdraw my earnings?',
      answer: 'You can withdraw your earnings to your connected crypto wallet at any time. We also offer options to convert to fiat currency and withdraw to your bank account in supported regions.'
    },
    {
      category: 'privacy',
      question: 'Does Monery comply with privacy regulations?',
      answer: 'Yes, Monery is designed to comply with global privacy regulations including GDPR, CCPA, and others. Our privacy-by-design architecture ensures your data sovereignty while meeting regulatory requirements.'
    },
    {
      category: 'general',
      question: 'What makes Monery different from traditional data brokers?',
      answer: 'Unlike traditional data brokers who collect and sell your data without permission or compensation, Monery puts you in control. You decide what to share, set your own prices, and receive the majority of the revenue generated from your data.'
    }
  ];

  const categories = [
    { id: 'all', name: 'All Questions' },
    { id: 'general', name: 'General' },
    { id: 'privacy', name: 'Privacy' },
    { id: 'marketplace', name: 'Marketplace' },
    { id: 'technical', name: 'Technical' }
  ];

  const filteredFaqs = faqs.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'all' || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-lg text-white/80 mb-8">
              Find answers to common questions about Monery, data monetization, and how our platform works.
            </p>
          </Animated>
          
          <Animated type="slide-up" delay={0.1}>
            <div className="relative max-w-xl mx-auto">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search for answers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
              />
            </div>
          </Animated>
        </div>
      </Section>

      <Section background="light" className="py-10">
        <div className="flex flex-wrap justify-center gap-4">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-4 py-2 rounded-md transition-colors ${
                activeCategory === category.id
                  ? 'bg-primary text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>
      </Section>

      <Section background="white" className="py-20">
        <div className="max-w-3xl mx-auto">
          {filteredFaqs.length > 0 ? (
            <div className="space-y-4">
              {filteredFaqs.map((faq, index) => (
                <Animated key={index} type="fade" delay={index * 0.05}>
                  <div className="border border-gray-200 rounded-lg overflow-hidden">
                    <button
                      onClick={() => setOpenIndex(openIndex === index ? null : index)}
                      className="w-full flex justify-between items-center p-6 text-left"
                    >
                      <h3 className="text-lg font-semibold">{faq.question}</h3>
                      {openIndex === index ? (
                        <ChevronUp className="h-5 w-5 text-primary flex-shrink-0" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-gray-400 flex-shrink-0" />
                      )}
                    </button>
                    <AnimatePresence>
                      {openIndex === index && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <div className="p-6 pt-0 border-t border-gray-200">
                            <p className="text-text-secondary">{faq.answer}</p>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </Animated>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-2">No results found</h3>
              <p className="text-text-secondary mb-6">
                Try adjusting your search or category filter to find what you're looking for.
              </p>
              <Button
                variant="primary"
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('all');
                }}
              >
                Reset Filters
              </Button>
            </div>
          )}
        </div>
      </Section>

      <Section background="light" centered className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h2 className="text-3xl font-bold mb-6">Still Have Questions?</h2>
            <p className="text-text-secondary mb-8">
              Can't find what you're looking for? Our support team is here to help.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="primary" href="mailto:support@monery.xyz">
                Contact Support
              </Button>
              <Button variant="outline" href="https://twitter.com/monery_xyz">
                Follow Us on Twitter
              </Button>
            </div>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default FaqPage;