import React, { useEffect } from 'react';
import Section from '../components/ui/Section';
import Animated from '../components/ui/Animated';

const PrivacyPolicyPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Monery Privacy Policy';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Privacy Policy
            </h1>
            <p className="text-lg text-white/80">
              Last updated: March 15, 2024
            </p>
          </Animated>
        </div>
      </Section>

      <Section background="white" className="py-20">
        <div className="max-w-3xl mx-auto prose">
          <Animated type="slide-up">
            <h2>Introduction</h2>
            <p>
              At Monery ("we," "us," or "our"), privacy is at the core of our mission. This Privacy 
              Policy explains how we collect, use, disclose, and safeguard your information when you 
              use our platform.
            </p>

            <h2>Information We Collect</h2>
            <h3>Information You Provide</h3>
            <ul>
              <li>Wallet address</li>
              <li>Email address (optional)</li>
              <li>Data you choose to tokenize</li>
              <li>Transaction history on our platform</li>
            </ul>

            <h3>Information Automatically Collected</h3>
            <ul>
              <li>Device information</li>
              <li>IP address</li>
              <li>Browser type</li>
              <li>Operating system</li>
            </ul>

            <h2>How We Use Your Information</h2>
            <p>We use the collected information for:</p>
            <ul>
              <li>Facilitating data tokenization and transactions</li>
              <li>Providing and improving our services</li>
              <li>Communicating with you about your account</li>
              <li>Ensuring platform security</li>
              <li>Complying with legal obligations</li>
            </ul>

            <h2>Data Security</h2>
            <p>
              We implement robust security measures to protect your information, including:
            </p>
            <ul>
              <li>End-to-end encryption</li>
              <li>Zero-knowledge proofs for data verification</li>
              <li>Secure smart contracts</li>
              <li>Regular security audits</li>
            </ul>

            <h2>Data Sharing</h2>
            <p>
              We only share your information in the following circumstances:
            </p>
            <ul>
              <li>When you explicitly authorize a data sale through our marketplace</li>
              <li>To comply with legal obligations</li>
              <li>To protect our rights or property</li>
              <li>In connection with a business transfer or acquisition</li>
            </ul>

            <h2>Your Rights</h2>
            <p>You have the right to:</p>
            <ul>
              <li>Access your personal information</li>
              <li>Correct inaccurate data</li>
              <li>Delete your account and associated data</li>
              <li>Withdraw consent for data processing</li>
              <li>Export your data</li>
            </ul>

            <h2>Cookies</h2>
            <p>
              We use cookies and similar tracking technologies to enhance your experience. You can 
              control cookie preferences through your browser settings.
            </p>

            <h2>Children's Privacy</h2>
            <p>
              Our services are not intended for users under 18. We do not knowingly collect 
              information from children.
            </p>

            <h2>Changes to This Policy</h2>
            <p>
              We may update this policy periodically. We will notify you of any material changes 
              through our platform or via email.
            </p>

            <h2>Contact Us</h2>
            <p>
              For questions about this Privacy Policy, please contact us at:
              <br />
              Email: privacy@monery.xyz
              <br />
              Address: 123 Blockchain Street, San Francisco, CA 94105
            </p>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default PrivacyPolicyPage;