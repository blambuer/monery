import React from 'react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';

const LaunchToken: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Launch New Token</h1>
      
      <Card className="max-w-2xl mx-auto">
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-4">Token Details</h2>
          
          <form className="space-y-6">
            <div>
              <label htmlFor="tokenName" className="block text-sm font-medium text-gray-700 mb-1">
                Token Name
              </label>
              <input
                type="text"
                id="tokenName"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter token name"
              />
            </div>

            <div>
              <label htmlFor="tokenSymbol" className="block text-sm font-medium text-gray-700 mb-1">
                Token Symbol
              </label>
              <input
                type="text"
                id="tokenSymbol"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter token symbol"
              />
            </div>

            <div>
              <label htmlFor="tokenDescription" className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                id="tokenDescription"
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter token description"
              />
            </div>

            <div>
              <label htmlFor="initialSupply" className="block text-sm font-medium text-gray-700 mb-1">
                Initial Supply
              </label>
              <input
                type="number"
                id="initialSupply"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter initial supply"
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">
                Launch Token
              </Button>
            </div>
          </form>
        </div>
      </Card>
    </div>
  );
};

export default LaunchToken;