import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Rocket, Database, Users, Coins } from 'lucide-react';
import { useWeb3Store } from '../../lib/store';

const DashboardHome: React.FC = () => {
  const { account, userData } = useWeb3Store();

  const quickActions = [
    {
      icon: <Rocket className="h-6 w-6" />,
      title: 'Launch New Token',
      description: 'Tokenize your data and start earning',
      path: '/app/launch',
      color: 'bg-primary'
    },
    {
      icon: <Database className="h-6 w-6" />,
      title: 'View My Tokens',
      description: 'Manage your data tokens',
      path: '/app/tokens',
      color: 'bg-secondary'
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: 'Referral Program',
      description: 'Invite friends and earn rewards',
      path: '/app/referral',
      color: 'bg-accent'
    },
    {
      icon: <Coins className="h-6 w-6" />,
      title: 'Check Balance',
      description: 'View your earnings and points',
      path: '/app/balance',
      color: 'bg-green-500'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-primary-dark rounded-xl p-8 text-white">
        <h2 className="text-2xl font-bold mb-2">
          Welcome back, {account?.slice(0, 6)}...{account?.slice(-4)}
        </h2>
        <p className="text-white/80">
          Your current balance: {userData?.total_points || 0} Points
        </p>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-xl font-semibold mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <motion.div
              key={action.path}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link
                to={action.path}
                className="block bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className={`${action.color} w-12 h-12 rounded-lg flex items-center justify-center text-white mb-4`}>
                  {action.icon}
                </div>
                <h4 className="text-lg font-semibold mb-2">{action.title}</h4>
                <p className="text-gray-600">{action.description}</p>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div>
        <h3 className="text-xl font-semibold mb-4">Recent Activity</h3>
        <div className="bg-white rounded-xl shadow-sm p-6">
          <p className="text-gray-500 text-center py-8">
            No recent activity to display
          </p>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;