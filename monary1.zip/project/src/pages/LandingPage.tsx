import React, { useEffect } from 'react';
import HeroSection from '../components/home/HeroSection';
import FeaturesSection from '../components/home/FeaturesSection';
import HowItWorksSection from '../components/home/HowItWorksSection';
import MarketplaceSection from '../components/home/MarketplaceSection';
import AiAssistantSection from '../components/home/AiAssistantSection';
import CtaSection from '../components/home/CtaSection';
import AboutSection from '../components/home/AboutSection';
import FaqSection from '../components/home/FaqSection';

const LandingPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Monery - Own, Manage & Monetize Your Data';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      <HeroSection />
      <AboutSection />
      <FeaturesSection />
      <HowItWorksSection />
      <MarketplaceSection />
      <AiAssistantSection />
      <FaqSection />
      <CtaSection />
    </div>
  );
};

export default LandingPage;