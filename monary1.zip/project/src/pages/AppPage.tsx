import React from 'react';
import { Navigate, Routes, Route } from 'react-router-dom';
import { useWeb3Store } from '../lib/store';
import DashboardLayout from '../components/layout/DashboardLayout';
import DashboardHome from './dashboard/DashboardHome';
import LaunchToken from './dashboard/LaunchToken';
import MyTokens from './dashboard/MyTokens';
import MyListings from './dashboard/MyListings';
import ReferralProgram from './dashboard/ReferralProgram';
import GameBalance from './dashboard/GameBalance';
import Leaderboard from './dashboard/Leaderboard';
import Settings from './dashboard/Settings';

const AppPage: React.FC = () => {
  const { account } = useWeb3Store();

  if (!account) {
    return <Navigate to="/" replace />;
  }

  return (
    <DashboardLayout>
      <Routes>
        <Route path="/" element={<DashboardHome />} />
        <Route path="/launch" element={<LaunchToken />} />
        <Route path="/tokens" element={<MyTokens />} />
        <Route path="/listings" element={<MyListings />} />
        <Route path="/referral" element={<ReferralProgram />} />
        <Route path="/balance" element={<GameBalance />} />
        <Route path="/leaderboard" element={<Leaderboard />} />
        <Route path="/settings" element={<Settings />} />
      </Routes>
    </DashboardLayout>
  );
};

export default AppPage;