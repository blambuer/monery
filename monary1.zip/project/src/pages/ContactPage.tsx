import React, { useEffect } from 'react';
import Section from '../components/ui/Section';
import Animated from '../components/ui/Animated';
import { Mail, MessageCircle, MapPin, Clock } from 'lucide-react';

const ContactPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Contact Monery - Get in Touch';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Contact Us
            </h1>
            <p className="text-lg text-white/80">
              Have questions or need assistance? We're here to help you get the most out of Monery.
            </p>
          </Animated>
        </div>
      </Section>

      <Section background="light" className="py-20">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Animated type="slide-in">
              <div className="bg-white p-8 rounded-xl shadow-lg">
                <h2 className="text-2xl font-bold mb-6">Get in Touch</h2>
                <form className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Your Name
                    </label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Subject
                    </label>
                    <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">
                      <option>General Inquiry</option>
                      <option>Technical Support</option>
                      <option>Partnership Opportunity</option>
                      <option>Report an Issue</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Message
                    </label>
                    <textarea
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-primary text-white py-3 rounded-lg hover:bg-primary-dark transition-colors"
                  >
                    Send Message
                  </button>
                </form>
              </div>
            </Animated>

            <div className="space-y-6">
              <Animated type="fade" delay={0.1}>
                <div className="bg-white p-6 rounded-xl shadow-lg">
                  <div className="flex items-start">
                    <div className="bg-primary/10 p-3 rounded-full mr-4">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Email Support</h3>
                      <p className="text-text-secondary mb-2">
                        For general inquiries and support:
                      </p>
                      <a
                        href="mailto:support@monery.xyz"
                        className="text-primary hover:text-primary-dark"
                      >
                        support@monery.xyz
                      </a>
                    </div>
                  </div>
                </div>
              </Animated>

              <Animated type="fade" delay={0.2}>
                <div className="bg-white p-6 rounded-xl shadow-lg">
                  <div className="flex items-start">
                    <div className="bg-primary/10 p-3 rounded-full mr-4">
                      <MessageCircle className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Live Chat</h3>
                      <p className="text-text-secondary mb-2">
                        Chat with our support team:
                      </p>
                      <p className="text-primary">Available 24/7</p>
                    </div>
                  </div>
                </div>
              </Animated>

              <Animated type="fade" delay={0.3}>
                <div className="bg-white p-6 rounded-xl shadow-lg">
                  <div className="flex items-start">
                    <div className="bg-primary/10 p-3 rounded-full mr-4">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Location</h3>
                      <p className="text-text-secondary">
                        123 Blockchain Street<br />
                        San Francisco, CA 94105<br />
                        United States
                      </p>
                    </div>
                  </div>
                </div>
              </Animated>

              <Animated type="fade" delay={0.4}>
                <div className="bg-white p-6 rounded-xl shadow-lg">
                  <div className="flex items-start">
                    <div className="bg-primary/10 p-3 rounded-full mr-4">
                      <Clock className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Business Hours</h3>
                      <p className="text-text-secondary">
                        Monday - Friday: 9:00 AM - 6:00 PM PST<br />
                        Saturday - Sunday: Closed
                      </p>
                    </div>
                  </div>
                </div>
              </Animated>
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
};

export default ContactPage;