import React, { useEffect } from 'react';
import Section from '../components/ui/Section';
import Animated from '../components/ui/Animated';
import { MessageCircle, Mail, Video, FileText } from 'lucide-react';
import Button from '../components/ui/Button';

const SupportPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Monery Support - Help Center';
    window.scrollTo(0, 0);
  }, []);

  const supportCategories = [
    {
      title: 'Getting Started',
      items: [
        'Account Setup',
        'Connecting Your Wallet',
        'Understanding Data Tokenization',
        'Marketplace Basics'
      ]
    },
    {
      title: 'Technical Support',
      items: [
        'Troubleshooting Connection Issues',
        'Transaction Problems',
        'Wallet Integration',
        'Platform Performance'
      ]
    },
    {
      title: 'Account & Security',
      items: [
        'Account Recovery',
        'Security Settings',
        'Privacy Controls',
        'Two-Factor Authentication'
      ]
    },
    {
      title: 'Marketplace',
      items: [
        'Listing Data',
        'Setting Prices',
        'Finding Buyers',
        'Transaction History'
      ]
    }
  ];

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              How Can We Help?
            </h1>
            <p className="text-lg text-white/80 mb-8">
              Find answers, get support, and resolve issues quickly.
            </p>
            <div className="relative max-w-xl mx-auto">
              <input
                type="text"
                placeholder="Search for help articles..."
                className="w-full px-6 py-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <button className="absolute right-4 top-1/2 transform -translate-y-1/2 text-primary">
                Search
              </button>
            </div>
          </Animated>
        </div>
      </Section>

      <Section background="light" className="py-20">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <Animated type="fade" delay={0.1}>
              <a href="#chat" className="block bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                <MessageCircle className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">Live Chat</h3>
                <p className="text-text-secondary">
                  Chat with our support team in real-time.
                </p>
              </a>
            </Animated>

            <Animated type="fade" delay={0.2}>
              <a href="#email" className="block bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                <Mail className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">Email Support</h3>
                <p className="text-text-secondary">
                  Get help via email within 24 hours.
                </p>
              </a>
            </Animated>

            <Animated type="fade" delay={0.3}>
              <a href="#tutorials" className="block bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                <Video className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">Video Tutorials</h3>
                <p className="text-text-secondary">
                  Learn through step-by-step guides.
                </p>
              </a>
            </Animated>

            <Animated type="fade" delay={0.4}>
              <a href="#docs" className="block bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                <FileText className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">Documentation</h3>
                <p className="text-text-secondary">
                  Browse detailed platform guides.
                </p>
              </a>
            </Animated>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {supportCategories.map((category, index) => (
              <Animated key={index} type="fade" delay={index * 0.1}>
                <div className="bg-white p-6 rounded-xl shadow-lg">
                  <h3 className="text-xl font-bold mb-4">{category.title}</h3>
                  <ul className="space-y-3">
                    {category.items.map((item, itemIndex) => (
                      <li key={itemIndex}>
                        <a
                          href={`#${item.toLowerCase().replace(/\s+/g, '-')}`}
                          className="flex items-center text-text-secondary hover:text-primary transition-colors"
                        >
                          <svg
                            className="h-4 w-4 mr-2"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M9 5l7 7-7 7"
                            />
                          </svg>
                          {item}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              </Animated>
            ))}
          </div>
        </div>
      </Section>

      <Section background="white" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h2 className="text-3xl font-bold mb-6">Still Need Help?</h2>
            <p className="text-text-secondary mb-8">
              Our support team is available 24/7 to assist you with any questions or concerns.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button variant="primary" href="mailto:support@monery.xyz">
                Contact Support
              </Button>
              <Button variant="outline" href="/faq">
                View FAQ
              </Button>
            </div>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default SupportPage;