import React, { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { toast } from 'react-hot-toast';
import { Search, Filter, ArrowUpDown } from 'lucide-react';
import Section from '../components/ui/Section';
import Button from '../components/ui/Button';
import { supabase } from '../lib/supabase';

interface DataToken {
  id: string;
  token_id: number;
  wallet_address: string;
  cid: string;
  name: string;
  category: string;
  description: string;
  price: number;
  is_listed: boolean;
  created_at: string;
}

const MarketplacePage: React.FC = () => {
  const { address } = useAccount();
  const [tokens, setTokens] = useState<DataToken[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'price' | 'newest'>('newest');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  useEffect(() => {
    fetchTokens();
  }, []);

  const fetchTokens = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('data_tokens')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTokens(data || []);
    } catch (error) {
      console.error('Error fetching tokens:', error);
      toast.error('Failed to load marketplace items');
    } finally {
      setLoading(false);
    }
  };

  const filteredTokens = tokens
    .filter(token => {
      const matchesSearch = 
        token.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        token.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filterCategory === 'all' || token.category === filterCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'price') {
        return b.price - a.price;
      }
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });

  const categories = [
    { id: 'all', name: 'All Categories' },
    { id: 'browsing', name: 'Browsing History' },
    { id: 'social', name: 'Social Activity' },
    { id: 'financial', name: 'Financial Data' },
    { id: 'health', name: 'Health Data' },
    { id: 'location', name: 'Location Data' }
  ];

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <div>
              <h1 className="text-4xl font-bold text-white mb-4">
                Data Marketplace
              </h1>
              <p className="text-white/80">
                Discover and acquire valuable data assets
              </p>
            </div>
            <Button
              variant="accent"
              size="lg"
              href="/app"
              className="mt-6 md:mt-0"
            >
              List Your Data
            </Button>
          </div>

          {/* Search and Filters */}
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search marketplace..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>

              <div className="relative">
                <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 h-5 w-5" />
                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-white appearance-none focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  {categories.map(category => (
                    <option key={category.id} value={category.id} className="text-gray-900">
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="relative">
                <ArrowUpDown className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 h-5 w-5" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'price' | 'newest')}
                  className="w-full bg-white/5 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-white appearance-none focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <option value="newest" className="text-gray-900">Newest First</option>
                  <option value="price" className="text-gray-900">Highest Price</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </Section>

      <Section background="light" className="py-20">
        <div className="max-w-7xl mx-auto">
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading marketplace items...</p>
            </div>
          ) : filteredTokens.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTokens.map((token) => (
                <div
                  key={token.id}
                  className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
                >
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-lg font-semibold mb-1">{token.name}</h3>
                        <p className="text-sm text-gray-500">{token.category}</p>
                      </div>
                      <div className="bg-primary/10 px-3 py-1 rounded-full">
                        <span className="text-primary font-medium">{token.price} MON</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mb-4 line-clamp-2">{token.description}</p>
                    
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-gray-500">
                        ID: {token.token_id}
                      </div>
                      <Button
                        variant="primary"
                        size="sm"
                        disabled={token.wallet_address === address?.toLowerCase()}
                      >
                        {token.wallet_address === address?.toLowerCase() ? 'Your Token' : 'Buy Now'}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-2">No items found</h3>
              <p className="text-gray-600 mb-6">
                {searchQuery || filterCategory !== 'all'
                  ? 'Try adjusting your search filters'
                  : 'Be the first to list your data!'}
              </p>
              <Button
                variant="primary"
                href="/app"
              >
                List Your Data
              </Button>
            </div>
          )}
        </div>
      </Section>
    </div>
  );
};

export default MarketplacePage;