import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Section from '../components/ui/Section';
import { useWeb3Store } from '../lib/store';
import WalletConnect from '../components/web3/WalletConnect';
import TokenizeDataModal from '../components/web3/TokenizeDataModal';
import ProfileCard from '../components/web3/ProfileCard';

const DashboardPage: React.FC = () => {
  const { account } = useWeb3Store();
  const [isModalOpen, setIsModalOpen] = React.useState(false);

  useEffect(() => {
    document.title = 'Monery Dashboard - Manage Your Data';
    window.scrollTo(0, 0);
  }, []);

  if (!account) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="pt-24">
      <Section background="gradient" className="py-20">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-2xl shadow-xl p-8"
          >
            <WalletConnect />
            <div className="mt-8">
              <button
                onClick={() => setIsModalOpen(true)}
                className="w-full btn btn-primary"
              >
                Tokenize New Data
              </button>
            </div>
          </motion.div>
        </div>
      </Section>

      <TokenizeDataModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
};

export default DashboardPage;