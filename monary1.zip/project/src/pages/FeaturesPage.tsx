import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import Section from '../components/ui/Section';
import Button from '../components/ui/Button';
import Animated from '../components/ui/Animated';
import { Database, Shield, ShoppingCart, Brain, Lock } from 'lucide-react';

const FeaturesPage: React.FC = () => {
  useEffect(() => {
    // Update the page title
    document.title = 'Monery Features - Own & Monetize Your Data';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);

  const features = [
    {
      id: 'data-vault',
      title: 'Personal Data Vault',
      description: 'Monery\'s encrypted vault ensures your browsing history, social interactions, and activities are secured and fully owned by you.',
      icon: <Database className="h-10 w-10" />,
      image: 'https://images.pexels.com/photos/5380642/pexels-photo-5380642.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      details: [
        'End-to-end encryption protects your sensitive information',
        'Decentralized storage prevents single points of failure',
        'Select which data to collect and which to ignore',
        'Compatible with all major browsers and devices'
      ]
    },
    {
      id: 'tokenization',
      title: 'Data Tokenization',
      description: 'Convert different types of your data into NFTs or SFTs, selectively choose what to monetize while maintaining full control.',
      icon: <Shield className="h-10 w-10" />,
      image: 'https://images.pexels.com/photos/8370764/pexels-photo-8370764.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      details: [
        'Transform raw data into valuable digital assets',
        'Set your own pricing and licensing terms',
        'Create data bundles for higher value offerings',
        'Maintain ownership even after transactions'
      ]
    },
    {
      id: 'marketplace',
      title: 'Data Marketplace',
      description: 'Access a decentralized marketplace where brands, researchers, and projects can offer to buy your data — transparently and fairly.',
      icon: <ShoppingCart className="h-10 w-10" />,
      image: 'https://images.pexels.com/photos/7681229/pexels-photo-7681229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      details: [
        'Connect with verified data buyers globally',
        'Escrow system ensures safe transactions',
        'No middlemen means higher earnings for you',
        'Review system builds reputation for quality data'
      ]
    },
    {
      id: 'ai-insights',
      title: 'AI-Powered Insights',
      description: 'Let our AI advisors recommend the best monetization strategies, predict the value of your data assets, and help you earn more.',
      icon: <Brain className="h-10 w-10" />,
      image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      details: [
        'Intelligent pricing recommendations',
        'Market demand forecasting',
        'Personalized earning strategies',
        'Value-increasing data enrichment suggestions'
      ]
    },
    {
      id: 'privacy',
      title: 'Full Privacy Control',
      description: 'Using zk-SNARK-like privacy protections, Monery ensures your identity and sensitive information are never exposed.',
      icon: <Lock className="h-10 w-10" />,
      image: 'https://images.pexels.com/photos/5380635/pexels-photo-5380635.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      details: [
        'Zero-knowledge proofs verify data without revealing content',
        'Granular permissions for different data types',
        'Anonymization tools protect your identity',
        'Compliance with global privacy regulations'
      ]
    }
  ];

  return (
    <div className="pt-24">
      {/* Hero Section */}
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Features That Put You in Control
            </h1>
          </Animated>
          <Animated type="slide-up" delay={0.1}>
            <p className="text-lg text-white/80 mb-8">
              Monery provides a comprehensive suite of tools designed to help you own, 
              protect, and monetize your personal data with maximum security and privacy.
            </p>
          </Animated>
          <Animated type="slide-up" delay={0.2}>
            <Button 
              variant="accent" 
              size="lg"
              href="/app"
            >
              Get Started
            </Button>
          </Animated>
        </div>
      </Section>

      {/* Features */}
      {features.map((feature, index) => (
        <Section 
          key={feature.id}
          id={feature.id}
          background={index % 2 === 0 ? 'light' : 'dark'}
          className="py-20"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className={index % 2 !== 0 ? 'order-2 lg:order-1' : ''}>
              <Animated type="slide-in">
                <div className={`rounded-full p-4 inline-flex mb-6 ${
                  index % 2 === 0 ? 'bg-primary/10' : 'bg-white/10'
                }`}>
                  <div className={index % 2 === 0 ? 'text-primary' : 'text-white'}>
                    {feature.icon}
                  </div>
                </div>
                <h2 className={`text-3xl font-bold mb-4 ${
                  index % 2 === 0 ? 'text-text-primary' : 'text-white'
                }`}>
                  {feature.title}
                </h2>
                <p className={`text-lg mb-8 ${
                  index % 2 === 0 ? 'text-text-secondary' : 'text-white/80'
                }`}>
                  {feature.description}
                </p>
                <ul className={`space-y-3 mb-8 ${
                  index % 2 === 0 ? 'text-text-secondary' : 'text-white/80'
                }`}>
                  {feature.details.map((detail, i) => (
                    <li key={i} className="flex items-start">
                      <div className={`rounded-full p-1 mr-3 mt-1 ${
                        index % 2 === 0 ? 'bg-primary/20' : 'bg-white/20'
                      }`}>
                        <svg 
                          className="h-3 w-3" 
                          fill="none" 
                          viewBox="0 0 24 24" 
                          stroke="currentColor"
                        >
                          <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={3}
                            d="M5 13l4 4L19 7" 
                          />
                        </svg>
                      </div>
                      {detail}
                    </li>
                  ))}
                </ul>
                <Button 
                  variant={index % 2 === 0 ? 'primary' : 'accent'} 
                  href={`/how-it-works#${feature.id}`}
                >
                  Learn More
                </Button>
              </Animated>
            </div>
            
            <div className={index % 2 !== 0 ? 'order-1 lg:order-2' : ''}>
              <Animated type="fade" delay={0.3}>
                <motion.div
                  whileHover={{ scale: 1.03 }}
                  transition={{ duration: 0.3 }}
                  className={`rounded-2xl overflow-hidden shadow-xl ${
                    index % 2 === 0 
                      ? 'shadow-gray-200/50' 
                      : 'shadow-gray-900/50'
                  }`}
                >
                  <img 
                    src={feature.image} 
                    alt={feature.title} 
                    className="w-full h-auto"
                  />
                </motion.div>
              </Animated>
            </div>
          </div>
        </Section>
      ))}

      {/* CTA Section */}
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to Experience Monery?
            </h2>
            <p className="text-lg text-white/80 mb-8">
              Join thousands of users who are already taking control of their digital footprint
              and earning from their data assets.
            </p>
            <Button 
              variant="accent" 
              size="lg"
              href="/app"
            >
              Download Now
            </Button>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default FeaturesPage;