import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import Section from '../components/ui/Section';
import Button from '../components/ui/Button';
import Animated from '../components/ui/Animated';
import { ArrowDown, ArrowRight, Database, Shield, DollarSign } from 'lucide-react';

const HowItWorksPage: React.FC = () => {
  useEffect(() => {
    // Update the page title
    document.title = 'How Monery Works - Data to Revenue';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);

  const steps = [
    {
      id: 'install',
      title: 'Install',
      description: 'Get our lightweight browser plugin or mobile app to start capturing your personal data in a private vault.',
      icon: <Database className="h-10 w-10" />,
      image: 'https://images.pexels.com/photos/6963944/pexels-photo-6963944.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      details: [
        'Download from App Store, Google Play, or Chrome Web Store',
        'Simple 30-second setup process',
        'No technical knowledge required',
        'Immediate protection begins after installation'
      ]
    },
    {
      id: 'tokenize',
      title: 'Tokenize',
      description: 'With a click, select and tokenize specific data sets you want to manage, sell, or stake.',
      icon: <Shield className="h-10 w-10" />,
      image: 'https://images.pexels.com/photos/8370602/pexels-photo-8370602.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      details: [
        'AI-assisted data categorization',
        'Choose which data types to tokenize',
        'Set privacy preferences and permissions',
        'Create multiple data packages for different purposes'
      ]
    },
    {
      id: 'monetize',
      title: 'Monetize',
      description: 'Access the Monery Marketplace to find buyers or stake your tokens to earn passive rewards.',
      icon: <DollarSign className="h-10 w-10" />,
      image: 'https://images.pexels.com/photos/6802042/pexels-photo-6802042.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      details: [
        'List data for direct sale to interested buyers',
        'Stake data tokens to earn passive income',
        'Join data pools for higher earnings potential',
        'Withdraw earnings to your preferred wallet or bank'
      ]
    }
  ];

  return (
    <div className="pt-24">
      {/* Hero Section */}
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              From Data to Revenue — Simple and Secure
            </h1>
          </Animated>
          <Animated type="slide-up" delay={0.1}>
            <p className="text-lg text-white/80 mb-8">
              Monery transforms the way you manage your digital footprint, making it easy to
              secure, tokenize, and profit from your personal data in just three simple steps.
            </p>
          </Animated>
          <Animated type="slide-up" delay={0.2}>
            <Button 
              variant="accent" 
              size="lg"
              href="/app"
            >
              Start Now
            </Button>
          </Animated>
        </div>
      </Section>

      {/* Process Overview */}
      <Section background="light" centered className="py-20">
        <Animated type="slide-up">
          <h2 className="text-3xl font-bold mb-16">The Monery Process</h2>
        </Animated>
        
        <div className="relative max-w-4xl mx-auto">
          {/* Process Steps */}
          <div className="flex flex-col md:flex-row justify-between items-start">
            {steps.map((step, index) => (
              <React.Fragment key={step.id}>
                <Animated type="fade" delay={index * 0.1} className="w-full md:w-1/3 text-center px-4">
                  <motion.div
                    whileHover={{ y: -10 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="bg-primary/10 p-6 rounded-full inline-flex mb-6">
                      <div className="text-primary">
                        {step.icon}
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                    <p className="text-text-secondary">{step.description}</p>
                  </motion.div>
                </Animated>
                
                {index < steps.length - 1 && (
                  <div className="hidden md:block text-primary my-12">
                    <ArrowRight size={32} />
                  </div>
                )}
                
                {index < steps.length - 1 && (
                  <div className="md:hidden text-primary my-6 mx-auto">
                    <ArrowDown size={32} />
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
          
          {/* Line connecting the steps (desktop only) */}
          <div className="hidden md:block absolute top-24 left-1/6 right-1/6 h-px bg-gray-200 z-0"></div>
        </div>
      </Section>

      {/* Detailed Steps */}
      {steps.map((step, index) => (
        <Section 
          key={step.id}
          id={step.id}
          background={index % 2 === 0 ? 'white' : 'dark'}
          className="py-20"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className={index % 2 !== 0 ? 'order-2 lg:order-1' : ''}>
              <Animated type="slide-in">
                <div className="flex items-center mb-6">
                  <div className={`rounded-full h-12 w-12 flex items-center justify-center text-xl font-bold mr-4 ${
                    index % 2 === 0 ? 'bg-primary text-white' : 'bg-accent text-text-primary'
                  }`}>
                    {index + 1}
                  </div>
                  <h2 className={`text-3xl font-bold ${
                    index % 2 === 0 ? 'text-text-primary' : 'text-white'
                  }`}>
                    Step {index + 1}: {step.title}
                  </h2>
                </div>
                <p className={`text-lg mb-8 ${
                  index % 2 === 0 ? 'text-text-secondary' : 'text-white/80'
                }`}>
                  {step.description}
                </p>
                <ul className={`space-y-4 mb-8 ${
                  index % 2 === 0 ? 'text-text-secondary' : 'text-white/80'
                }`}>
                  {step.details.map((detail, i) => (
                    <li key={i} className="flex items-start">
                      <div className={`rounded-full p-1 mr-3 mt-1 ${
                        index % 2 === 0 ? 'bg-primary/20' : 'bg-white/20'
                      }`}>
                        <svg 
                          className="h-3 w-3" 
                          fill="none" 
                          viewBox="0 0 24 24" 
                          stroke="currentColor"
                        >
                          <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={3}
                            d="M5 13l4 4L19 7" 
                          />
                        </svg>
                      </div>
                      {detail}
                    </li>
                  ))}
                </ul>
                {index === steps.length - 1 ? (
                  <Button 
                    variant={index % 2 === 0 ? 'primary' : 'accent'} 
                    href="/app"
                  >
                    Start Earning Now
                  </Button>
                ) : (
                  <Button 
                    variant={index % 2 === 0 ? 'primary' : 'accent'} 
                    href={`#${steps[index + 1].id}`}
                  >
                    Next Step
                  </Button>
                )}
              </Animated>
            </div>
            
            <div className={index % 2 !== 0 ? 'order-1 lg:order-2' : ''}>
              <Animated type="fade" delay={0.3}>
                <motion.div
                  whileHover={{ scale: 1.03 }}
                  transition={{ duration: 0.3 }}
                  className={`rounded-2xl overflow-hidden shadow-xl ${
                    index % 2 === 0 
                      ? 'shadow-gray-200/50' 
                      : 'shadow-gray-900/50'
                  }`}
                >
                  <img 
                    src={step.image} 
                    alt={step.title} 
                    className="w-full h-auto"
                  />
                </motion.div>
              </Animated>
            </div>
          </div>
        </Section>
      ))}

      {/* Flow Diagram */}
      <Section background="light" centered className="py-20">
        <div className="max-w-4xl mx-auto">
          <Animated type="slide-up">
            <h2 className="text-3xl font-bold mb-6">Visual Flow Diagram</h2>
            <p className="text-text-secondary mb-12">
              See how data moves through the Monery platform, from collection to monetization.
            </p>
          </Animated>
          
          <Animated type="fade" delay={0.2}>
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <img 
                src="https://images.pexels.com/photos/7567440/pexels-photo-7567440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                alt="Monery Flow Diagram" 
                className="w-full h-auto rounded-md"
              />
            </div>
          </Animated>
        </div>
      </Section>

      {/* CTA Section */}
      <Section background="gradient" className="py-20">
        <div className="max-w-3xl mx-auto text-center">
          <Animated type="slide-up">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to Start Your Journey?
            </h2>
            <p className="text-lg text-white/80 mb-8">
              Join thousands of users who are already earning from their data with Monery.
              It takes less than a minute to get started.
            </p>
            <Button 
              variant="accent" 
              size="lg"
              href="/app"
            >
              Download Now
            </Button>
          </Animated>
        </div>
      </Section>
    </div>
  );
};

export default HowItWorksPage;