import { useEffect } from 'react';
import { useUserStore } from '../lib/store';

export const useGameification = () => {
  const { addXP, addBadge, updateLoginStreak } = useUserStore();

  useEffect(() => {
    // Update daily login streak
    updateLoginStreak();
    
    // Award XP for daily login
    addXP(10);
  }, []);

  const awardXP = (action: string) => {
    const xpRewards: Record<string, number> = {
      'connect_wallet': 50,
      'first_data_upload': 100,
      'first_sale': 200,
      'referral': 50,
      'complete_profile': 75,
      'daily_login': 10
    };

    const xp = xpRewards[action] || 0;
    if (xp > 0) {
      addXP(xp);
    }
  };

  const checkBadgeEligibility = (action: string, value: number) => {
    const badgeCriteria: Record<string, { threshold: number; badge: string }> = {
      'sales': { threshold: 1000, badge: 'Data Master' },
      'referrals': { threshold: 5, badge: 'Referral King' },
      'login_streak': { threshold: 7, badge: 'Daily Grinder' }
    };

    const criteria = badgeCriteria[action];
    if (criteria && value >= criteria.threshold) {
      addBadge(criteria.badge);
    }
  };

  return {
    awardXP,
    checkBadgeEligibility
  };
};