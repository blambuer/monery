import { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { getTokenBalance } from '../lib/contracts';
import { createOrUpdateUser, getUserData } from '../lib/supabase';

export const useWeb3 = () => {
  const [account, setAccount] = useState<string | null>(null);
  const [chainId, setChainId] = useState<number | null>(null);
  const [signer, setSigner] = useState<ethers.Signer | null>(null);
  const [provider, setProvider] = useState<ethers.Provider | null>(null);
  const [loading, setLoading] = useState(false);
  const [nativeBalance, setNativeBalance] = useState<string | null>(null);
  const [tokenBalance, setTokenBalance] = useState<string | null>(null);
  const [userData, setUserData] = useState<any>(null);

  const connect = async () => {
    if (!window.ethereum) {
      throw new Error('Please install MetaMask');
    }

    try {
      setLoading(true);
      const provider = new ethers.BrowserProvider(window.ethereum);
      const network = await provider.getNetwork();
      setChainId(Number(network.chainId));

      // Request account access
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      const account = accounts[0];
      setAccount(account);

      // Get signer
      const signer = await provider.getSigner();
      setSigner(signer);
      setProvider(provider);

      // Get balances
      const balance = await provider.getBalance(account);
      setNativeBalance(ethers.formatEther(balance));

      const rymonBalance = await getTokenBalance(provider, account);
      setTokenBalance(rymonBalance);

      // Create or update user in database
      await createOrUpdateUser(account);
      const userData = await getUserData(account);
      setUserData(userData);
    } catch (error) {
      console.error('Connection error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const refreshUserData = async () => {
    if (account) {
      try {
        const userData = await getUserData(account);
        setUserData(userData);
      } catch (error) {
        console.error('Error refreshing user data:', error);
      }
    }
  };

  useEffect(() => {
    const handleAccountsChanged = async (accounts: string[]) => {
      if (accounts.length === 0) {
        setAccount(null);
        setSigner(null);
        setUserData(null);
      } else {
        setAccount(accounts[0]);
        if (accounts[0]) {
          await createOrUpdateUser(accounts[0]);
          const userData = await getUserData(accounts[0]);
          setUserData(userData);
        }
      }
    };

    const handleChainChanged = (chainId: string) => {
      window.location.reload();
    };

    if (window.ethereum) {
      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);

      return () => {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, []);

  return {
    connect,
    account,
    chainId,
    signer,
    provider,
    loading,
    nativeBalance,
    tokenBalance,
    userData,
    refreshUserData
  };
};