export interface DataMetadata {
  dataTypes: string[];
  createdAt: string;
  description?: string;
  tags?: string[];
}

export async function uploadToIPFS(metadata: DataMetadata): Promise<string> {
  try {
    const url = `https://api.pinata.cloud/pinning/pinJSONToIPFS`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySW5mb3JtYXRpb24iOnsiaWQiOiIwMTQ1ZDEwOC00ZGYzLTQ1ZTMtYWEyMy05NGFhNWQ4NjYzMTIiLCJlbWFpbCI6InF1b2trYWN1dGUwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJwaW5fcG9saWN5Ijp7InJlZ2lvbnMiOlt7ImRlc2lyZWRSZXBsaWNhdGlvbkNvdW50IjoxLCJpZCI6IkZSQTEifSx7ImRlc2lyZWRSZXBsaWNhdGlvbkNvdW50IjoxLCJpZCI6Ik5ZQzEifV0sInZlcnNpb24iOjF9LCJtZmFfZW5hYmxlZCI6ZmFsc2UsInN0YXR1cyI6IkFDVElWRSJ9LCJhdXRoZW50aWNhdGlvblR5cGUiOiJzY29wZWRLZXkiLCJzY29wZWRLZXlLZXkiOiJhYzk0ZGFmODgyZDA5OWVkYWZjYiIsInNjb3BlZEtleVNlY3JldCI6IjJlYmRiMjQwNGM3OGE1MjQ1OTljNmY0MTQ3YWU5NmVmOTgwMDQ3NGFjMmI2ZjE5NzE0YTczMzg3OGNiYWE5NjYiLCJleHAiOjE3NzczOTYxMTJ9.5ACEbzIGNLOZVNXU2YC3zu5_msUjdIU39OMwlm_1uLo`
      },
      body: JSON.stringify({
        pinataContent: metadata,
        pinataOptions: {
          cidVersion: 1
        },
        pinataMetadata: {
          name: `data-token-metadata-${Date.now()}`,
          keyvalues: {
            type: 'data-token',
            timestamp: Date.now().toString()
          }
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Failed to upload to IPFS', errorText);
      throw new Error('Failed to upload to IPFS via Pinata');
    }

    const data = await response.json();
    console.log('Uploaded metadata hash (CID):', data.IpfsHash);
    return `https://gateway.pinata.cloud/ipfs/${data.IpfsHash}`;
  } catch (error) {
    console.error('IPFS upload error:', error);
    throw new Error('Failed to upload data to IPFS');
  }
}

export async function getFromIPFS(cid: string): Promise<DataMetadata> {
  try {
    // Use Pinata gateway for retrieving files
    const response = await fetch(`https://gateway.pinata.cloud/ipfs/${cid}`);
    if (!response.ok) {
      throw new Error('Failed to fetch from IPFS');
    }
    return response.json();
  } catch (error) {
    console.error('IPFS fetch error:', error);
    throw new Error('Failed to fetch data from IPFS');
  }
}

export async function uploadFileToIPFS(file: File): Promise<string> {
  try {
    const url = `https://api.pinata.cloud/pinning/pinFileToIPFS`;

    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySW5mb3JtYXRpb24iOnsiaWQiOiIwMTQ1ZDEwOC00ZGYzLTQ1ZTMtYWEyMy05NGFhNWQ4NjYzMTIiLCJlbWFpbCI6InF1b2trYWN1dGUwQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJwaW5fcG9saWN5Ijp7InJlZ2lvbnMiOlt7ImRlc2lyZWRSZXBsaWNhdGlvbkNvdW50IjoxLCJpZCI6IkZSQTEifSx7ImRlc2lyZWRSZXBsaWNhdGlvbkNvdW50IjoxLCJpZCI6Ik5ZQzEifV0sInZlcnNpb24iOjF9LCJtZmFfZW5hYmxlZCI6ZmFsc2UsInN0YXR1cyI6IkFDVElWRSJ9LCJhdXRoZW50aWNhdGlvblR5cGUiOiJzY29wZWRLZXkiLCJzY29wZWRLZXlLZXkiOiJhYzk0ZGFmODgyZDA5OWVkYWZjYiIsInNjb3BlZEtleVNlY3JldCI6IjJlYmRiMjQwNGM3OGE1MjQ1OTljNmY0MTQ3YWU5NmVmOTgwMDQ3NGFjMmI2ZjE5NzE0YTczMzg3OGNiYWE5NjYiLCJleHAiOjE3NzczOTYxMTJ9.5ACEbzIGNLOZVNXU2YC3zu5_msUjdIU39OMwlm_1uLo`
      },
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Failed to upload to IPFS', errorText);
      throw new Error('Failed to upload to IPFS via Pinata');
    }

    const data = await response.json();
    console.log('Uploaded file hash (CID):', data.IpfsHash);
    return `https://gateway.pinata.cloud/ipfs/${data.IpfsHash}`;
  } catch (error) {
    console.error('IPFS upload error:', error);
    throw new Error('Failed to upload file to IPFS');
  }
}