import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL?.trim();
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim();

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

// Validate URL format
try {
  new URL(supabaseUrl);
} catch (error) {
  throw new Error('Invalid Supabase URL format');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  }
});

export const createOrUpdateUser = async (walletAddress: string) => {
  try {
    const normalizedAddress = walletAddress.toLowerCase();
    const email = `${normalizedAddress}@monery.xyz`;
    
    // First check if user already exists
    const { data: existingUser } = await supabase
      .from('user_points')
      .select('wallet_address')
      .eq('wallet_address', normalizedAddress)
      .single();

    // If user doesn't exist, create auth account first
    if (!existingUser) {
      const { error: signUpError } = await supabase.auth.signUp({
        email,
        password: normalizedAddress,
        options: {
          data: {
            wallet_address: normalizedAddress
          }
        }
      });

      if (signUpError) {
        // If signup fails, try signing in
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password: normalizedAddress
        });

        if (signInError) {
          throw new Error('Failed to authenticate user');
        }
      }

      // Wait for session to be established
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Now create or update the user_points record
    const { data, error } = await supabase
      .from('user_points')
      .upsert(
        { 
          wallet_address: normalizedAddress,
          total_points: 0,
          credit_score: 500,
          network: 'monad_testnet',
          last_login: new Date().toISOString()
        },
        { 
          onConflict: 'wallet_address'
        }
      );

    if (error) {
      throw error;
    }

    return data;
  } catch (error) {
    console.error('Error in createOrUpdateUser:', error);
    throw error;
  }
};

export const getUserData = async (walletAddress: string) => {
  try {
    const { data, error } = await supabase
      .from('user_points')
      .select('*')
      .eq('wallet_address', walletAddress.toLowerCase())
      .single();

    if (error) {
      console.error('Error fetching user data:', error);
      throw error;
    }
    
    return data;
  } catch (error) {
    console.error('Error in getUserData:', error);
    throw error;
  }
};

export const updateUserPoints = async (walletAddress: string, points: number) => {
  try {
    const { data, error } = await supabase
      .from('user_points')
      .update({ total_points: points })
      .eq('wallet_address', walletAddress.toLowerCase())
      .select();

    if (error) {
      console.error('Error updating user points:', error);
      throw error;
    }
    
    return data;
  } catch (error) {
    console.error('Error in updateUserPoints:', error);
    throw error;
  }
};