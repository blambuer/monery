import { ethers } from 'ethers';
import { supabase } from './supabase';

const MONAD_TESTNET = {
  chainId: '0x279f',  // 10143 in hex
  chainName: 'Monad Testnet',
  nativeCurrency: {
    name: 'MON',
    symbol: 'MON',
    decimals: 18
  },
  rpcUrls: ['https://testnet-rpc.monad.xyz'],
  blockExplorerUrls: ['https://testnet.monadexplorer.com']
};

const switchToMonadNetwork = async () => {
  if (!window.ethereum) throw new Error('Please install MetaMask');

  try {
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: MONAD_TESTNET.chainId }],
    });
  } catch (switchError: any) {
    if (switchError.code === 4902) {
      try {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [MONAD_TESTNET],
        });
      } catch (addError) {
        throw new Error('Failed to add Monad network to MetaMask');
      }
    } else {
      throw switchError;
    }
  }
};

const generateSignMessage = (address: string) => {
  return `Welcome to Monery!\n\nSign this message to authenticate and access the platform.\n\nThis signature will not trigger any blockchain transaction or cost any gas fees.\n\nWallet: ${address}\nNetwork: Monad Testnet\nTimestamp: ${Date.now()}`;
};

export const connectWallet = async () => {
  if (!window.ethereum) {
    throw new Error('Please install MetaMask to use this feature');
  }

  try {
    await switchToMonadNetwork();
    
    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    const address = accounts[0];
    const normalizedAddress = address.toLowerCase();
    
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    
    // Get signature for authentication
    const signMessage = generateSignMessage(normalizedAddress);
    const signature = await signer.signMessage(signMessage);
    
    // Create user record first
    const { data: userData, error: userError } = await supabase
      .from('user_points')
      .upsert({
        wallet_address: normalizedAddress,
        auth_signature: signature,
        last_login: new Date().toISOString(),
        network: 'monad_testnet',
        total_points: 0,
        credit_score: 500
      }, {
        onConflict: 'wallet_address'
      });

    if (userError) {
      console.error('Database error:', userError);
      throw new Error('Failed to store wallet information');
    }

    return {
      provider,
      signer,
      account: normalizedAddress,
      signature
    };
  } catch (error: any) {
    console.error('Error connecting wallet:', error);
    throw error;
  }
};

export const getTokenBalance = async (address: string, provider: ethers.Provider) => {
  try {
    const balance = await provider.getBalance(address);
    return ethers.formatEther(balance);
  } catch (error) {
    console.error('Error getting balance:', error);
    throw error;
  }
};

export const verifySignature = async (address: string) => {
  try {
    const { data, error } = await supabase
      .from('user_points')
      .select('auth_signature')
      .eq('wallet_address', address.toLowerCase())
      .single();

    if (error) throw error;
    return !!data?.auth_signature;
  } catch (error) {
    console.error('Error verifying signature:', error);
    return false;
  }
};