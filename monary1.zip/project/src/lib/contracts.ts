import { ethers } from 'ethers';

export const MonadTestnet = {
  chainId: 10143,
  name: 'Monad Testnet',
  nativeCurrency: {
    name: 'MON',
    symbol: 'MON',
    decimals: 18
  },
  rpcUrls: ['https://testnet-rpc.monad.xyz'],
  blockExplorerUrls: ['https://testnet.monadexplorer.com']
};

export const switchToMonadNetwork = async () => {
  if (!window.ethereum) throw new Error('Please install MetaMask');

  try {
    // Try to switch to the Monad network
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: `0x${MonadTestnet.chainId.toString(16)}` }],
    });
  } catch (switchError: any) {
    // This error code indicates that the chain has not been added to MetaMask
    if (switchError.code === 4902) {
      try {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: `0x${MonadTestnet.chainId.toString(16)}`,
            chainName: MonadTestnet.name,
            nativeCurrency: MonadTestnet.nativeCurrency,
            rpcUrls: MonadTestnet.rpcUrls,
            blockExplorerUrls: MonadTestnet.blockExplorerUrls
          }],
        });
      } catch (addError) {
        throw new Error('Failed to add Monad network to MetaMask');
      }
    } else {
      throw switchError;
    }
  }
};

export const getTokenBalance = async (provider: ethers.Provider, address: string) => {
  try {
    const balance = await provider.getBalance(address);
    return ethers.formatEther(balance);
  } catch (error) {
    console.error('Error getting token balance:', error);
    return '0';
  }
};

export const tokenizeData = async (signer: ethers.Signer, ipfsUrl: string, price: bigint) => {
  try {
    // TODO: Implement actual tokenization logic once smart contract is deployed
    await new Promise(resolve => setTimeout(resolve, 2000));
    return true;
  } catch (error) {
    console.error('Error tokenizing data:', error);
    throw error;
  }
};