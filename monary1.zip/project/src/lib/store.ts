import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { ethers } from 'ethers';
import { createOrUpdateUser, getUserData } from './supabase';
import { connectWallet, getTokenBalance } from './web3';

interface Web3State {
  account: string | null;
  chainId: number | null;
  signer: ethers.Signer | null;
  provider: ethers.Provider | null;
  loading: boolean;
  nativeBalance: string | null;
  tokenBalance: string | null;
  userData: any;
  error: string | null;
  connect: () => Promise<void>;
  disconnect: () => void;
  refreshBalances: () => Promise<void>;
  refreshUserData: () => Promise<void>;
  setError: (error: string | null) => void;
}

export const useWeb3Store = create<Web3State>()(
  persist(
    (set, get) => ({
      account: null,
      chainId: null,
      signer: null,
      provider: null,
      loading: false,
      nativeBalance: null,
      tokenBalance: null,
      userData: null,
      error: null,

      connect: async () => {
        try {
          set({ loading: true, error: null });
          
          const { provider, signer, account } = await connectWallet();
          
          // Get network info
          const network = await provider.getNetwork();
          
          // Get balances
          const balance = await provider.getBalance(account);
          const tokenBalance = await getTokenBalance(account, provider);
          
          let userData = null;
          
          try {
            // Try to get user data first
            userData = await getUserData(account);
          } catch (error) {
            // If user data doesn't exist, create the user
            try {
              await createOrUpdateUser(account);
              userData = await getUserData(account);
            } catch (createError: any) {
              // If user already exists, just get their data
              if (createError.message?.includes('already registered')) {
                userData = await getUserData(account);
              } else {
                throw createError;
              }
            }
          }

          set({
            account,
            chainId: Number(network.chainId),
            signer,
            provider,
            nativeBalance: ethers.formatEther(balance),
            tokenBalance,
            userData,
            loading: false,
            error: null
          });
        } catch (error: any) {
          console.error('Connection error:', error);
          set({ 
            error: error instanceof Error ? error.message : 'Failed to connect wallet',
            loading: false 
          });
        }
      },

      disconnect: () => {
        set({
          account: null,
          chainId: null,
          signer: null,
          provider: null,
          nativeBalance: null,
          tokenBalance: null,
          userData: null,
          error: null
        });
      },

      refreshBalances: async () => {
        const { provider, account } = get();
        if (!provider || !account) return;

        try {
          const balance = await provider.getBalance(account);
          const tokenBalance = await getTokenBalance(account, provider);
          set({ 
            nativeBalance: ethers.formatEther(balance),
            tokenBalance
          });
        } catch (error) {
          console.error('Error refreshing balances:', error);
        }
      },

      refreshUserData: async () => {
        const { account } = get();
        if (!account) return;

        try {
          const userData = await getUserData(account);
          set({ userData });
        } catch (error) {
          console.error('Error refreshing user data:', error);
        }
      },

      setError: (error) => set({ error })
    }),
    {
      name: 'web3-storage',
      partialize: (state) => ({
        account: state.account,
        chainId: state.chainId
      })
    }
  )
);