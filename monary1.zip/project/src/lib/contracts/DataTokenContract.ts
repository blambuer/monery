import { getContract } from 'viem';
import { type WalletClient, type PublicClient } from 'wagmi';

export const DataTokenABI = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "uint256",
        "name": "tokenId",
        "type": "uint256"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "owner",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "string",
        "name": "cid",
        "type": "string"
      },
      {
        "indexed": false,
        "internalType": "string",
        "name": "name",
        "type": "string"
      },
      {
        "indexed": false,
        "internalType": "string",
        "name": "category",
        "type": "string"
      }
    ],
    "name": "DataTokenized",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "string",
        "name": "cid",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "name",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "category",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "description",
        "type": "string"
      }
    ],
    "name": "tokenizeData",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

export const DataTokenAddress = "0xfa15f33c87a42c4dbef0768e5cdf5f2c8af2e373";

export async function tokenizeData(
  walletClient: WalletClient,
  publicClient: PublicClient,
  cid: string,
  name: string,
  category: string,
  description: string
): Promise<`0x${string}`> {
  if (!walletClient.account) {
    throw new Error('No account connected');
  }

  try {
    const { request } = await publicClient.simulateContract({
      address: DataTokenAddress as `0x${string}`,
      abi: DataTokenABI,
      functionName: 'tokenizeData',
      args: [cid, name, category, description],
      account: walletClient.account.address,
    });

    const hash = await walletClient.writeContract(request);
    return hash;
  } catch (error) {
    console.error('Tokenization error:', error);
    throw error;
  }
}