import { getContract } from 'viem';
import { type WalletClient, type PublicClient } from 'wagmi';

export const MarketplaceABI = [
  {
    "inputs": [
      {"internalType": "uint256","name": "tokenId","type": "uint256"},
      {"internalType": "uint256","name": "price","type": "uint256"}
    ],
    "name": "listToken",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "uint256","name": "tokenId","type": "uint256"}],
    "name": "unlistToken",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "uint256","name": "tokenId","type": "uint256"}],
    "name": "buyToken",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  }
];

export const MarketplaceAddress = "0xfa15f33c87a42c4dbef0768e5cdf5f2c8af2e373";

export async function listDataToken(
  walletClient: WalletClient,
  publicClient: PublicClient,
  tokenId: number,
  price: bigint
): Promise<`0x${string}`> {
  if (!walletClient.account) {
    throw new Error('No account connected');
  }

  try {
    const { request } = await publicClient.simulateContract({
      address: MarketplaceAddress as `0x${string}`,
      abi: MarketplaceABI,
      functionName: 'listToken',
      args: [tokenId, price],
      account: walletClient.account.address,
    });

    const hash = await walletClient.writeContract(request);
    return hash;
  } catch (error) {
    console.error('Error listing token:', error);
    throw error;
  }
}

export async function buyDataToken(
  walletClient: WalletClient,
  publicClient: PublicClient,
  tokenId: number,
  price: bigint
): Promise<`0x${string}`> {
  if (!walletClient.account) {
    throw new Error('No account connected');
  }

  try {
    const { request } = await publicClient.simulateContract({
      address: MarketplaceAddress as `0x${string}`,
      abi: MarketplaceABI,
      functionName: 'buyToken',
      args: [tokenId],
      account: walletClient.account.address,
      value: price
    });

    const hash = await walletClient.writeContract(request);
    return hash;
  } catch (error) {
    console.error('Error buying token:', error);
    throw error;
  }
}

export async function unlistDataToken(
  walletClient: WalletClient,
  publicClient: PublicClient,
  tokenId: number
): Promise<`0x${string}`> {
  if (!walletClient.account) {
    throw new Error('No account connected');
  }

  try {
    const { request } = await publicClient.simulateContract({
      address: MarketplaceAddress as `0x${string}`,
      abi: MarketplaceABI,
      functionName: 'unlistToken',
      args: [tokenId],
      account: walletClient.account.address,
    });

    const hash = await walletClient.writeContract(request);
    return hash;
  } catch (error) {
    console.error('Error unlisting token:', error);
    throw error;
  }
}