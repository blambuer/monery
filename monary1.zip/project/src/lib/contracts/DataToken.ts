import { ethers } from 'ethers';

export const DataTokenABI = [
  "function tokenizeData(string ipfsUrl, uint256 price) external returns (uint256)",
  "function purchaseData(uint256 id) external payable",
  "function dataItems(uint256) external view returns (address owner, string ipfsUrl, uint256 price, bool isSold)",
  "function nextId() external view returns (uint256)"
];

export const DataTokenAddress = "0xYourContractAddressHere";

export interface DataItem {
  id: number;
  owner: string;
  ipfsUrl: string;
  price: bigint;
  isSold: boolean;
}

export function getDataTokenContract(provider: ethers.Provider) {
  return new ethers.Contract(DataTokenAddress, DataTokenABI, provider);
}

export async function tokenizeData(
  signer: ethers.Signer,
  ipfsUrl: string,
  price: bigint
): Promise<ethers.TransactionResponse> {
  try {
    const contract = getDataTokenContract(signer.provider!).connect(signer);
    return await contract.tokenizeData(ipfsUrl, price);
  } catch (error) {
    console.error('Tokenization error:', error);
    throw new Error('Failed to tokenize data');
  }
}

export async function purchaseData(
  signer: ethers.Signer,
  id: number,
  price: bigint
): Promise<ethers.TransactionResponse> {
  try {
    const contract = getDataTokenContract(signer.provider!).connect(signer);
    return await contract.purchaseData(id, { value: price });
  } catch (error) {
    console.error('Purchase error:', error);
    throw new Error('Failed to purchase data');
  }
}

export async function getDataItem(provider: ethers.Provider, id: number): Promise<DataItem> {
  try {
    const contract = getDataTokenContract(provider);
    const item = await contract.dataItems(id);
    return {
      id,
      owner: item.owner,
      ipfsUrl: item.ipfsUrl,
      price: item.price,
      isSold: item.isSold
    };
  } catch (error) {
    console.error('Fetch error:', error);
    throw new Error('Failed to fetch data item');
  }
}