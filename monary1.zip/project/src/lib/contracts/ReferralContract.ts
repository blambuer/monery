import { ethers } from 'ethers';

export const ReferralContractABI = [
  {
    "inputs": [{"internalType": "address","name": "referrer","type": "address"}],
    "name": "registerReferral",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "address","name": "user","type": "address"}],
    "name": "referrerOf",
    "outputs": [{"internalType": "address","name": "","type": "address"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "address","name": "user","type": "address"}],
    "name": "referralRewards",
    "outputs": [{"internalType": "uint256","name": "","type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "claimRewards",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

export const ReferralContractAddress = "0xYourDeployedReferralContractAddress";

export const getReferralContract = (provider: ethers.Provider) => {
  return new ethers.Contract(ReferralContractAddress, ReferralContractABI, provider);
};

export const registerReferral = async (signer: ethers.Signer, referrerAddress: string) => {
  try {
    const contract = getReferralContract(signer.provider!).connect(signer);
    const tx = await contract.registerReferral(referrerAddress);
    await tx.wait();
    return tx;
  } catch (error) {
    console.error('Error registering referral:', error);
    throw error;
  }
};

export const getReferrer = async (provider: ethers.Provider, userAddress: string) => {
  try {
    const contract = getReferralContract(provider);
    const referrer = await contract.referrerOf(userAddress);
    return referrer;
  } catch (error) {
    console.error('Error getting referrer:', error);
    throw error;
  }
};

export const getReferralRewards = async (provider: ethers.Provider, userAddress: string) => {
  try {
    const contract = getReferralContract(provider);
    const rewards = await contract.referralRewards(userAddress);
    return ethers.formatEther(rewards);
  } catch (error) {
    console.error('Error getting referral rewards:', error);
    throw error;
  }
};

export const claimReferralRewards = async (signer: ethers.Signer) => {
  try {
    const contract = getReferralContract(signer.provider!).connect(signer);
    const tx = await contract.claimRewards();
    await tx.wait();
    return tx;
  } catch (error) {
    console.error('Error claiming rewards:', error);
    throw error;
  }
};