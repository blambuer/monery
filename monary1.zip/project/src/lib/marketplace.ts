import { ethers } from 'ethers';

export const MoneryMarketplaceABI = [
  {
    "inputs": [
      {"internalType": "uint256","name": "amount","type": "uint256"},
      {"internalType": "uint256","name": "price","type": "uint256"},
      {"internalType": "string","name": "category","type": "string"}
    ],
    "name": "listData",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "uint256","name": "listingId","type": "uint256"}],
    "name": "buyData",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getListings",
    "outputs": [
      {
        "components": [
          {"internalType": "uint256","name": "id","type": "uint256"},
          {"internalType": "address","name": "seller","type": "address"},
          {"internalType": "uint256","name": "amount","type": "uint256"},
          {"internalType": "uint256","name": "price","type": "uint256"},
          {"internalType": "string","name": "category","type": "string"},
          {"internalType": "bool","name": "active","type": "bool"},
          {"internalType": "uint256","name": "timestamp","type": "uint256"}
        ],
        "internalType": "struct MoneryMarketplace.Listing[]",
        "name": "",
        "type": "tuple[]"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
];

export const MoneryMarketplaceAddress = "0xYourDeployedMarketplaceAddress";

export const getMarketplaceContract = (provider: ethers.Provider) => {
  return new ethers.Contract(MoneryMarketplaceAddress, MoneryMarketplaceABI, provider);
};

export const getListings = async (provider: ethers.Provider) => {
  try {
    const contract = getMarketplaceContract(provider);
    const listings = await contract.getListings();
    return listings;
  } catch (error) {
    console.error('Error getting listings:', error);
    throw error;
  }
};

export const listData = async (
  signer: ethers.Signer,
  amount: bigint,
  price: bigint,
  category: string
) => {
  try {
    const contract = getMarketplaceContract(signer.provider!).connect(signer);
    const tx = await contract.listData(amount, price, category);
    await tx.wait();
    return tx;
  } catch (error) {
    console.error('Error listing data:', error);
    throw error;
  }
};

export const buyData = async (
  signer: ethers.Signer,
  listingId: number,
  price: bigint
) => {
  try {
    const contract = getMarketplaceContract(signer.provider!).connect(signer);
    const tx = await contract.buyData(listingId, { value: price });
    await tx.wait();
    return tx;
  } catch (error) {
    console.error('Error buying data:', error);
    throw error;
  }
};