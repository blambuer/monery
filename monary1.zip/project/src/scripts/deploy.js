import { ethers } from 'ethers';
import fs from 'fs';

async function main() {
  // Connect to Monad Testnet
  const provider = new ethers.JsonRpcProvider('https://testnet-rpc.monad.xyz');
  
  // Load private key from environment variable or config
  const privateKey = process.env.PRIVATE_KEY;
  if (!privateKey) {
    throw new Error('Missing PRIVATE_KEY environment variable');
  }

  const wallet = new ethers.Wallet(privateKey, provider);
  console.log('Deploying contracts with account:', wallet.address);

  // Deploy DataToken contract
  const DataToken = await ethers.getContractFactory('DataToken', wallet);
  console.log('Deploying DataToken...');
  const dataToken = await DataToken.deploy();
  await dataToken.waitForDeployment();

  const dataTokenAddress = await dataToken.getAddress();
  console.log('DataToken deployed to:', dataTokenAddress);

  // Update contract address in frontend config
  const configPath = './src/lib/contracts/DataTokenContract.ts';
  let configContent = fs.readFileSync(configPath, 'utf8');
  configContent = configContent.replace(
    /export const DataTokenAddress = ".*"/,
    `export const DataTokenAddress = "${dataTokenAddress}"`
  );
  fs.writeFileSync(configPath, configContent);

  console.log('Contract address updated in frontend config');
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });