import { cookieStorage, createStorage } from 'wagmi'
import { WagmiAdapter } from '@reown/appkit-adapter-wagmi'
import { monadTestnet } from './networks'

export const projectId = '59e43396c3cc1eef5c2d79aa7a8b14b5'

if (!projectId) {
  throw new Error('Project ID is not defined')
}

export const networks = [monadTestnet]

export const wagmiAdapter = new WagmiAdapter({
  storage: createStorage({
    storage: cookieStorage
  }),
  ssr: true,
  projectId,
  networks
})

export const config = wagmiAdapter.wagmiConfig