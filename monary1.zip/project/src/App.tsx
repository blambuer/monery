import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { WalletProvider } from './context/WalletProvider';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import LandingPage from './pages/LandingPage';
import AppPage from './pages/AppPage';
import MarketplacePage from './pages/MarketplacePage';

function App() {
  return (
    <WalletProvider>
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/app" element={<AppPage />} />
            <Route path="/marketplace" element={<MarketplacePage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </WalletProvider>
  );
}

export default App;