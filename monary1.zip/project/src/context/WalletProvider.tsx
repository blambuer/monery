import React from 'react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { createAppKit } from '@reown/appkit/react'
import { wagmiAdapter, projectId } from '../config/wallet'
import { monadTestnet } from '../config/networks'
import { WagmiProvider, cookieToInitialState } from 'wagmi'

const queryClient = new QueryClient()

const metadata = {
  name: 'Monery',
  description: 'Data Tokenization Platform',
  url: typeof window !== 'undefined' ? window.location.origin : '',
  icons: ['https://assets.reown.com/reown-profile-pic.png']
}

export const modal = createAppKit({
  adapters: [wagmiAdapter],
  projectId,
  networks: [monadTestnet],
  defaultNetwork: monadTestnet,
  metadata,
  features: {
    analytics: false // Disable analytics in development
  }
})

interface WalletProviderProps {
  children: React.ReactNode
  cookies?: string | null
}

export function WalletProvider({ children, cookies }: WalletProviderProps) {
  const initialState = cookies ? cookieToInitialState(wagmiAdapter.wagmiConfig, cookies) : undefined

  return (
    <WagmiProvider config={wagmiAdapter.wagmiConfig} initialState={initialState}>
      <QueryClientProvider client={queryClient}>
        {children}
      </QueryClientProvider>
    </WagmiProvider>
  )
}