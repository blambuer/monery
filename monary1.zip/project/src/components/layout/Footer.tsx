import React from 'react';
import { Link } from 'react-router-dom';
import { Send, Twitter, Linkedin, Facebook, Github } from 'lucide-react';
import Logo from '../ui/Logo';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  const links = {
    product: [
      { title: 'Features', path: '/features' },
      { title: 'How It Works', path: '/how-it-works' },
      { title: 'Launch App', path: 'https://app.monery.xyz' },
    ],
    company: [
      { title: 'About', path: '/about' },
      { title: 'FAQ', path: '/faq' },
      { title: 'Contact', path: 'mailto:support@monery.xyz' },
    ],
    resources: [
      { title: 'Privacy Policy', path: '/privacy' },
      { title: 'Terms of Service', path: '/terms' },
      { title: 'Support', path: 'mailto:support@monery.xyz' },
    ],
  };

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-16">
          <div className="lg:col-span-2">
            <Logo variant="light" />
            <p className="mt-4 text-gray-400 max-w-sm">
              Own your digital footprint. Earn from your data — fully private, fully yours.
              Powered by AI & Blockchain.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="https://twitter.com/monery_xyz" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Twitter size={20} />
              </a>
              <a href="https://linkedin.com/company/monery" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="https://facebook.com/moneryxyz" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="https://github.com/monery" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Github size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Product</h3>
            <ul className="space-y-3">
              {links.product.map((link) => (
                <li key={link.path}>
                  {link.path.startsWith('http') ? (
                    <a 
                      href={link.path}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-white transition-colors"
                    >
                      {link.title}
                    </a>
                  ) : (
                    <Link to={link.path} className="text-gray-400 hover:text-white transition-colors">
                      {link.title}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-3">
              {links.company.map((link) => (
                <li key={link.path}>
                  {link.path.startsWith('mailto:') ? (
                    <a 
                      href={link.path}
                      className="text-gray-400 hover:text-white transition-colors"
                    >
                      {link.title}
                    </a>
                  ) : (
                    <Link to={link.path} className="text-gray-400 hover:text-white transition-colors">
                      {link.title}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-3">
              {links.resources.map((link) => (
                <li key={link.path}>
                  {link.path.startsWith('mailto:') ? (
                    <a 
                      href={link.path}
                      className="text-gray-400 hover:text-white transition-colors"
                    >
                      {link.title}
                    </a>
                  ) : (
                    <Link to={link.path} className="text-gray-400 hover:text-white transition-colors">
                      {link.title}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <p className="text-gray-500 text-sm">
              &copy; {currentYear} Monery. All rights reserved.
            </p>
            <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-8 mt-4 md:mt-0">
              <div className="relative max-w-md">
                <input 
                  type="email" 
                  placeholder="Subscribe to newsletter" 
                  className="w-full py-3 px-4 pr-12 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary text-white"
                />
                <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-primary hover:text-primary-light transition-colors">
                  <Send size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;