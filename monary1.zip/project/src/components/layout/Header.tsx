import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import Logo from '../ui/Logo';
import WalletConnect from '../web3/WalletConnect';
import { useWeb3Store } from '../../lib/store';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { account } = useWeb3Store();

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      setScrolled(offset > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  const links = [
    { title: 'About', path: '/#about' },
    { title: 'Features', path: '/#features' },
    { title: 'How It Works', path: '/#how-it-works' },
    { title: 'Whitepaper', path: '/whitepaper' },
    { title: 'FAQ', path: '/#faq' },
  ];

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-white/90 backdrop-blur-md shadow-md py-3' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container-custom flex justify-between items-center">
        <Link to="/" className="z-50">
          <Logo />
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {links.map((link) => (
            <a 
              key={link.path}
              href={link.path}
              className={`font-medium transition-colors ${
                location.hash === link.path.substring(1) 
                  ? 'text-primary-dark'
                  : scrolled ? 'text-text-primary hover:text-primary' : 'text-text-primary hover:text-primary'
              }`}
            >
              {link.title}
            </a>
          ))}
          {account ? (
            <Link to="/app" className="btn btn-primary">
              Launch App
            </Link>
          ) : (
            <WalletConnect />
          )}
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden z-50 text-text-primary"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
        
        {/* Mobile Menu */}
        <div 
          className={`fixed inset-0 bg-white md:hidden transition-transform duration-300 ease-in-out z-40 ${
            isMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <div className="flex flex-col items-center justify-center h-full space-y-8">
            {links.map((link) => (
              <a 
                key={link.path}
                href={link.path}
                className={`text-xl font-medium ${
                  location.hash === link.path.substring(1) 
                    ? 'text-primary' 
                    : 'text-text-primary'
                }`}
              >
                {link.title}
              </a>
            ))}
            {account ? (
              <Link to="/app" className="btn btn-primary">
                Launch App
              </Link>
            ) : (
              <WalletConnect />
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;