import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { 
  Home, 
  Rocket, 
  Database, 
  ShoppingCart, 
  Users, 
  Gamepad2, 
  Trophy, 
  Settings,
  LogOut
} from 'lucide-react';
import { useWeb3Store } from '../../lib/store';
import { ConnectButton } from '../web3/ConnectButton';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  to: string;
  active: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, to, active }) => (
  <Link
    to={to}
    className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
      active 
        ? 'bg-primary text-white' 
        : 'hover:bg-gray-100'
    }`}
  >
    {icon}
    <span className="font-medium">{label}</span>
  </Link>
);

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const location = useLocation();
  const { account, disconnect } = useWeb3Store();

  const sidebarItems = [
    { icon: <Home className="h-5 w-5" />, label: 'Home', path: '/app' },
    { icon: <Rocket className="h-5 w-5" />, label: 'Launch New Token', path: '/app/launch' },
    { icon: <Database className="h-5 w-5" />, label: 'My Data Tokens', path: '/app/tokens' },
    { icon: <ShoppingCart className="h-5 w-5" />, label: 'My Listings', path: '/app/listings' },
    { icon: <Users className="h-5 w-5" />, label: 'Referral Program', path: '/app/referral' },
    { icon: <Gamepad2 className="h-5 w-5" />, label: 'Game Balance', path: '/app/balance' },
    { icon: <Trophy className="h-5 w-5" />, label: 'Leaderboard', path: '/app/leaderboard' },
    { icon: <Settings className="h-5 w-5" />, label: 'Settings', path: '/app/settings' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 w-64 h-screen bg-white border-r border-gray-200 z-30">
        <div className="flex flex-col h-full">
          <div className="p-6">
            <Link to="/" className="text-2xl font-bold text-primary">Monery</Link>
          </div>

          <nav className="flex-grow px-4 space-y-1">
            {sidebarItems.map((item) => (
              <SidebarItem
                key={item.path}
                icon={item.icon}
                label={item.label}
                to={item.path}
                active={location.pathname === item.path}
              />
            ))}
          </nav>

          <div className="p-4 border-t border-gray-200">
            <button
              onClick={() => disconnect()}
              className="flex items-center space-x-3 px-4 py-3 w-full rounded-lg text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut className="h-5 w-5" />
              <span className="font-medium">Disconnect</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="ml-64">
        {/* Top Navbar */}
        <header className="sticky top-0 z-20 bg-white border-b border-gray-200">
          <div className="flex items-center justify-between px-8 py-4">
            <h1 className="text-2xl font-bold">
              {sidebarItems.find(item => item.path === location.pathname)?.label || 'Dashboard'}
            </h1>
            <div className="flex items-center space-x-4">
              <ConnectButton />
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;