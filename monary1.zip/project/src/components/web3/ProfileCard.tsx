import React from 'react';
import { motion } from 'framer-motion';
import { Coins, Trophy, Users, Gift, ChevronRight } from 'lucide-react';
import * as Avatar from '@radix-ui/react-avatar';
import * as Progress from '@radix-ui/react-progress';
import * as Tabs from '@radix-ui/react-tabs';

interface ProfileCardProps {
  account: string;
  nativeBalance: string;
  rymonBalance: string;
  userData: any;
}

const ProfileCard: React.FC<ProfileCardProps> = ({
  account,
  nativeBalance,
  rymonBalance,
  userData
}) => {
  const points = userData?.total_points || 0;
  const creditScore = userData?.credit_score || 500;
  const rank = Math.floor(points / 1000) + 1;

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6 max-w-2xl mx-auto">
      <div className="flex items-center space-x-4 mb-6">
        <Avatar.Root className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
          <Avatar.Fallback className="text-2xl font-bold text-primary">
            {account.slice(2, 4).toUpperCase()}
          </Avatar.Fallback>
        </Avatar.Root>
        
        <div>
          <h2 className="text-lg font-semibold">{account.slice(0, 6)}...{account.slice(-4)}</h2>
          <div className="flex items-center text-sm text-gray-500">
            <span className="flex items-center">
              <Trophy className="h-4 w-4 mr-1" />
              Rank #{rank}
            </span>
            <span className="mx-2">•</span>
            <span>{points} Points</span>
          </div>
        </div>
      </div>

      <Tabs.Root defaultValue="balances" className="space-y-6">
        <Tabs.List className="flex space-x-2 border-b border-gray-200">
          <Tabs.Trigger
            value="balances"
            className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-primary data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
          >
            Balances
          </Tabs.Trigger>
          <Tabs.Trigger
            value="stats"
            className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-primary data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
          >
            Stats
          </Tabs.Trigger>
          <Tabs.Trigger
            value="rewards"
            className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-primary data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary"
          >
            Rewards
          </Tabs.Trigger>
        </Tabs.List>

        <Tabs.Content value="balances" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-gradient-to-r from-primary to-primary-dark p-4 rounded-xl text-white"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm opacity-80">MON Balance</span>
                <Coins className="h-5 w-5 opacity-80" />
              </div>
              <div className="text-2xl font-bold">{nativeBalance} MON</div>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.02 }}
              className="bg-gradient-to-r from-secondary to-secondary-dark p-4 rounded-xl text-white"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm opacity-80">RYMON Balance</span>
                <Coins className="h-5 w-5 opacity-80" />
              </div>
              <div className="text-2xl font-bold">{rymonBalance} RYMON</div>
            </motion.div>
          </div>
        </Tabs.Content>

        <Tabs.Content value="stats" className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-xl">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-medium">Credit Score</h3>
                <p className="text-sm text-gray-500">Based on your activity</p>
              </div>
              <div className="text-2xl font-bold text-primary">{creditScore}</div>
            </div>
            <Progress.Root className="h-2 bg-gray-200 rounded-full overflow-hidden" value={(creditScore - 300) / 5}>
              <Progress.Indicator
                className="h-full bg-primary transition-transform duration-500"
                style={{ transform: `translateX(-${100 - ((creditScore - 300) / 5)}%)` }}
              />
            </Progress.Root>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-xl">
              <h3 className="font-medium mb-1">Total Points</h3>
              <p className="text-2xl font-bold text-primary">{points}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-xl">
              <h3 className="font-medium mb-1">Rank</h3>
              <p className="text-2xl font-bold text-primary">#{rank}</p>
            </div>
          </div>
        </Tabs.Content>

        <Tabs.Content value="rewards" className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-xl">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-medium">Available Rewards</h3>
                <p className="text-sm text-gray-500">Complete tasks to earn more</p>
              </div>
              <Gift className="h-5 w-5 text-primary" />
            </div>
            <Progress.Root className="h-2 bg-gray-200 rounded-full overflow-hidden" value={65}>
              <Progress.Indicator
                className="h-full bg-primary transition-transform duration-500"
                style={{ transform: `translateX(-${100 - 65}%)` }}
              />
            </Progress.Root>
            <div className="mt-2 text-sm text-gray-500">
              65/100 points until next reward
            </div>
          </div>
        </Tabs.Content>
      </Tabs.Root>
    </div>
  );
};

export default ProfileCard;