import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wallet, Loader } from 'lucide-react';
import Button from '../ui/Button';
import { useWeb3Store } from '../../lib/store';

const WalletConnect: React.FC = () => {
  const { connect, account, loading, error: storeError } = useWeb3Store();
  const [error, setError] = useState<string | null>(null);

  const handleConnect = async () => {
    try {
      setError(null);
      await connect();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to connect wallet');
    }
  };

  const displayError = error || storeError;

  return (
    <div className="space-y-4">
      <Button
        variant="primary"
        size="lg"
        onClick={handleConnect}
        disabled={loading}
        className="flex items-center justify-center w-full"
      >
        {loading ? (
          <Loader className="animate-spin h-5 w-5 mr-2" />
        ) : (
          <Wallet className="h-5 w-5 mr-2" />
        )}
        Connect Wallet
      </Button>

      {displayError && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-50 text-red-600 p-4 rounded-xl text-center"
        >
          {displayError}
        </motion.div>
      )}
    </div>
  );
};

export default WalletConnect;