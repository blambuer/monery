import React from 'react'
import { useAccount, useConnect, useDisconnect } from 'wagmi'
import { modal } from '../../context/WalletProvider'
import Button from '../ui/Button'
import { Wallet, Loader } from 'lucide-react'

export function ConnectButton() {
  const { address, isConnected } = useAccount()
  const { disconnect } = useDisconnect()
  const { connect, isPending } = useConnect()

  if (isConnected && address) {
    return (
      <div className="flex items-center gap-4">
        <span className="text-sm text-gray-600">
          {address.slice(0, 6)}...{address.slice(-4)}
        </span>
        <Button
          variant="outline"
          onClick={() => disconnect()}
          className="flex items-center"
        >
          Disconnect
        </Button>
      </div>
    )
  }

  return (
    <Button
      variant="primary"
      onClick={() => modal.open()}
      disabled={isPending}
      className="flex items-center"
    >
      {isPending ? (
        <Loader className="animate-spin h-5 w-5 mr-2" />
      ) : (
        <Wallet className="h-5 w-5 mr-2" />
      )}
      Connect Wallet
    </Button>
  )
}