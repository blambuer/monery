import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, AlertCircle, Loader } from 'lucide-react';
import Button from '../ui/Button';
import { useWeb3Store } from '../../lib/store';
import { uploadToIPFS, DataMetadata } from '../../lib/ipfs';
import { tokenizeData } from '../../lib/contracts/DataToken';
import { ethers } from 'ethers';

interface DataCategory {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

const dataCategories: DataCategory[] = [
  {
    id: 'browsing',
    name: 'Web Browsing Data',
    description: 'Browser history and activity patterns',
    icon: '🌐'
  },
  {
    id: 'social',
    name: 'Social Media Activity',
    description: 'Likes, shares, and engagement data',
    icon: '👥'
  },
  {
    id: 'purchase',
    name: 'Purchase History',
    description: 'Online shopping and transaction data',
    icon: '🛍️'
  },
  {
    id: 'fitness',
    name: 'Fitness Data',
    description: 'Exercise and health tracking metrics',
    icon: '💪'
  },
  {
    id: 'location',
    name: 'Location History',
    description: 'GPS and movement patterns',
    icon: '📍'
  },
  {
    id: 'app_usage',
    name: 'App Usage',
    description: 'Application usage statistics',
    icon: '📱'
  },
  {
    id: 'streaming',
    name: 'Streaming History',
    description: 'Media consumption patterns',
    icon: '🎬'
  },
  {
    id: 'survey',
    name: 'Survey Answers',
    description: 'Questionnaire responses',
    icon: '📝'
  },
  {
    id: 'gaming',
    name: 'Gaming Data',
    description: 'Gaming activity and achievements',
    icon: '🎮'
  },
  {
    id: 'financial',
    name: 'Financial Data',
    description: 'Spending patterns and transactions',
    icon: '💰'
  },
  {
    id: 'device',
    name: 'Device Information',
    description: 'Hardware and software details',
    icon: '📱'
  },
  {
    id: 'health',
    name: 'Health Data',
    description: 'Wellness and medical information',
    icon: '❤️'
  }
];

const TokenizeDataForm: React.FC = () => {
  const { signer } = useWeb3Store();
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dataFile, setDataFile] = useState<File | null>(null);

  const handleCategoryToggle = (categoryId: string) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type === 'application/json') {
        setDataFile(file);
        setError(null);
      } else {
        setError('Please upload a JSON file');
        setDataFile(null);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!signer) {
      setError('Please connect your wallet first');
      return;
    }

    if (selectedCategories.length === 0) {
      setError('Please select at least one data category');
      return;
    }

    if (!price || parseFloat(price) <= 0) {
      setError('Please enter a valid price');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Prepare metadata
      const metadata: DataMetadata = {
        dataTypes: selectedCategories,
        createdAt: new Date().toISOString(),
        description: description,
        tags: selectedCategories
      };

      // Upload to IPFS
      const ipfsUrl = await uploadToIPFS(metadata);

      // Tokenize data
      const priceInWei = ethers.parseEther(price);
      const tx = await tokenizeData(signer, ipfsUrl, priceInWei);
      await tx.wait();

      // Reset form
      setSelectedCategories([]);
      setDescription('');
      setPrice('');
      setDataFile(null);

      alert('Data successfully tokenized!');
    } catch (err) {
      console.error('Tokenization error:', err);
      setError(err instanceof Error ? err.message : 'Failed to tokenize data');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Select Data Categories</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {dataCategories.map((category) => (
            <motion.div
              key={category.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`p-4 rounded-lg cursor-pointer border-2 transition-colors ${
                selectedCategories.includes(category.id)
                  ? 'border-primary bg-primary/5'
                  : 'border-gray-200 hover:border-primary/50'
              }`}
              onClick={() => handleCategoryToggle(category.id)}
            >
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{category.icon}</span>
                <div>
                  <h4 className="font-medium">{category.name}</h4>
                  <p className="text-sm text-gray-500">{category.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Description (optional)
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          rows={3}
          placeholder="Add a description for your data token..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Upload Data File (JSON)
        </label>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
          <input
            type="file"
            accept="application/json"
            onChange={handleFileChange}
            className="hidden"
            id="data-file"
          />
          <label
            htmlFor="data-file"
            className="cursor-pointer flex flex-col items-center"
          >
            <Upload className="h-8 w-8 text-gray-400 mb-2" />
            <span className="text-sm text-gray-500">
              {dataFile ? dataFile.name : 'Click to upload JSON file'}
            </span>
          </label>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Price (MON)
        </label>
        <input
          type="number"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          min="0"
          step="0.01"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
          placeholder="Enter price in MON"
        />
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-lg flex items-center">
          <AlertCircle className="h-5 w-5 mr-2" />
          {error}
        </div>
      )}

      <Button
        variant="primary"
        type="submit"
        disabled={loading}
        className="w-full"
      >
        {loading ? (
          <Loader className="animate-spin h-5 w-5 mx-auto" />
        ) : (
          'Tokenize Data'
        )}
      </Button>
    </form>
  );
};

export default TokenizeDataForm;