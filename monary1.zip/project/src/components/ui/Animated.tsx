import React, { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface AnimatedProps {
  children: ReactNode;
  type?: 'fade' | 'slide-up' | 'slide-in' | 'scale';
  delay?: number;
  duration?: number;
  className?: string;
}

const Animated: React.FC<AnimatedProps> = ({
  children,
  type = 'fade',
  delay = 0,
  duration = 0.5,
  className = '',
}) => {
  let initialProps = {};
  let animateProps = {};

  switch (type) {
    case 'fade':
      initialProps = { opacity: 0 };
      animateProps = { opacity: 1 };
      break;
    case 'slide-up':
      initialProps = { opacity: 0, y: 50 };
      animateProps = { opacity: 1, y: 0 };
      break;
    case 'slide-in':
      initialProps = { opacity: 0, x: -50 };
      animateProps = { opacity: 1, x: 0 };
      break;
    case 'scale':
      initialProps = { opacity: 0, scale: 0.8 };
      animateProps = { opacity: 1, scale: 1 };
      break;
    default:
      initialProps = { opacity: 0 };
      animateProps = { opacity: 1 };
  }

  return (
    <motion.div
      className={className}
      initial={initialProps}
      whileInView={animateProps}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration, delay, ease: 'easeOut' }}
    >
      {children}
    </motion.div>
  );
};

export default Animated;