import React, { ReactNode } from 'react';
import { Link } from 'react-router-dom';

interface ButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'accent' | 'outline' | 'text';
  size?: 'sm' | 'md' | 'lg';
  href?: string;
  type?: 'button' | 'submit' | 'reset';
  onClick?: () => void;
  className?: string;
  fullWidth?: boolean;
  disabled?: boolean;
  external?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  href,
  type = 'button',
  onClick,
  className = '',
  fullWidth = false,
  disabled = false,
  external = false,
}) => {
  // Build classes based on props
  let variantClass = '';
  switch (variant) {
    case 'primary':
      variantClass = 'btn-primary';
      break;
    case 'secondary':
      variantClass = 'btn-secondary';
      break;
    case 'accent':
      variantClass = 'btn-accent';
      break;
    case 'outline':
      variantClass = 'btn-outline';
      break;
    case 'text':
      variantClass = 'text-primary hover:text-primary-dark underline-offset-4 hover:underline';
      break;
  }

  let sizeClass = '';
  switch (size) {
    case 'sm':
      sizeClass = 'text-sm py-1.5 px-4';
      break;
    case 'md':
      sizeClass = 'text-base py-2.5 px-6';
      break;
    case 'lg':
      sizeClass = 'text-lg py-3 px-8';
      break;
  }

  const allClasses = `${
    variant !== 'text' ? 'btn' : ''
  } ${variantClass} ${sizeClass} ${fullWidth ? 'w-full' : ''} ${
    disabled ? 'opacity-60 cursor-not-allowed' : ''
  } ${className}`;

  // Render as link if href is provided
  if (href) {
    if (external) {
      return (
        <a
          href={href}
          className={allClasses}
          target="_blank"
          rel="noopener noreferrer"
        >
          {children}
        </a>
      );
    }
    return (
      <Link to={href} className={allClasses}>
        {children}
      </Link>
    );
  }

  // Render as button
  return (
    <button
      type={type}
      onClick={onClick}
      className={allClasses}
      disabled={disabled}
    >
      {children}
    </button>
  );
};

export default Button;