import React, { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface CardProps {
  children: ReactNode;
  className?: string;
  variant?: 'default' | 'glass' | 'gradient';
  delay?: number;
}

export const Card: React.FC<CardProps> = ({ 
  children, 
  className = '', 
  variant = 'default',
  delay = 0 
}) => {
  let cardStyle = '';
  
  switch(variant) {
    case 'glass':
      cardStyle = 'card-glass';
      break;
    case 'gradient':
      cardStyle = 'gradient-bg text-white';
      break;
    default:
      cardStyle = 'card';
  }
  
  return (
    <motion.div 
      className={`${cardStyle} ${className}`}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay }}
    >
      {children}
    </motion.div>
  );
};

export default Card;