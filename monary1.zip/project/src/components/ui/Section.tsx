import React, { ReactNode } from 'react';

interface SectionProps {
  children: ReactNode;
  id?: string;
  className?: string;
  title?: string;
  subtitle?: string;
  background?: 'light' | 'dark' | 'gradient' | 'none';
  centered?: boolean;
}

const Section: React.FC<SectionProps> = ({
  children,
  id,
  className = '',
  title,
  subtitle,
  background = 'light',
  centered = false,
}) => {
  let bgClass = '';
  let textClass = '';

  switch (background) {
    case 'dark':
      bgClass = 'bg-gray-900';
      textClass = 'text-white';
      break;
    case 'gradient':
      bgClass = 'gradient-bg';
      textClass = 'text-white';
      break;
    case 'none':
      bgClass = '';
      textClass = '';
      break;
    default:
      bgClass = 'bg-white';
      textClass = '';
  }

  return (
    <section id={id} className={`section ${bgClass} ${className}`}>
      <div className="container-custom">
        {(title || subtitle) && (
          <div className={`mb-12 ${centered ? 'text-center' : ''}`}>
            {title && (
              <h2 className={`mb-4 font-bold ${textClass}`}>{title}</h2>
            )}
            {subtitle && (
              <p className={`text-lg md:text-xl max-w-3xl ${centered ? 'mx-auto' : ''} ${textClass ? textClass : 'text-text-secondary'}`}>
                {subtitle}
              </p>
            )}
          </div>
        )}
        {children}
      </div>
    </section>
  );
};

export default Section;