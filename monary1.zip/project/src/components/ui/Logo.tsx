import React from 'react';
import { Database } from 'lucide-react';

interface LogoProps {
  variant?: 'light' | 'dark';
}

const Logo: React.FC<LogoProps> = ({ variant = 'dark' }) => {
  const textColor = variant === 'light' ? 'text-white' : 'text-gray-900';
  
  return (
    <div className="flex items-center space-x-2">
      <div className="bg-gradient-to-r from-primary to-secondary p-2 rounded-lg">
        <Database className="h-6 w-6 text-white" />
      </div>
      <span className={`font-bold text-xl ${textColor}`}>Monery</span>
    </div>
  );
};

export default Logo;