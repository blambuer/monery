import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Shield, Database, Coins } from 'lucide-react';
import Button from '../ui/Button';
import Animated from '../ui/Animated';

const HeroSection: React.FC = () => {
  return (
    <div className="relative pt-28 pb-20 md:pt-32 md:pb-24 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className="absolute w-full h-[200%] top-0 left-0 right-0 z-0 opacity-10 animate-data-flow">
          <div className="grid grid-cols-12 gap-4 h-full">
            {Array.from({ length: 50 }).map((_, i) => (
              <div 
                key={i} 
                className="h-20 bg-gradient-to-b from-primary-light to-transparent rounded-md opacity-30"
                style={{ 
                  gridColumn: `span ${Math.floor(Math.random() * 2) + 1}`,
                  height: `${Math.floor(Math.random() * 120) + 30}px`,
                  animationDelay: `${Math.random() * 5}s`
                }}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="container-custom relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-left space-y-6">
            <Animated type="slide-up">
              <h1 className="text-5xl md:text-6xl font-bold leading-tight">
                Take Back Control of Your Data. <span className="text-primary">Monetize</span> It.
              </h1>
            </Animated>

            <Animated type="slide-up" delay={0.2}>
              <p className="text-text-secondary text-lg md:text-xl max-w-xl mx-auto lg:mx-0">
                Monery lets you own, manage, and earn from your personal data — powered by AI and Monad's high-speed blockchain.
              </p>
            </Animated>

            <Animated type="slide-up" delay={0.4}>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mt-8">
                <Button variant="primary" size="lg" href="/app">
                  Get Started <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button variant="outline" size="lg" href="/how-it-works">
                  Learn More
                </Button>
              </div>
            </Animated>

            <Animated type="fade" delay={0.6}>
              <div className="pt-8 grid grid-cols-3 gap-4 max-w-xl mx-auto lg:mx-0">
                <div className="flex flex-col items-center lg:items-start">
                  <div className="rounded-full p-2 bg-primary/10 mb-3">
                    <Database className="h-5 w-5 text-primary" />
                  </div>
                  <p className="text-sm text-text-secondary">Data Ownership</p>
                </div>
                <div className="flex flex-col items-center lg:items-start">
                  <div className="rounded-full p-2 bg-primary/10 mb-3">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <p className="text-sm text-text-secondary">Zero-Knowledge Privacy</p>
                </div>
                <div className="flex flex-col items-center lg:items-start">
                  <div className="rounded-full p-2 bg-primary/10 mb-3">
                    <Coins className="h-5 w-5 text-primary" />
                  </div>
                  <p className="text-sm text-text-secondary">Real Revenue</p>
                </div>
              </div>
            </Animated>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="relative z-10"
            >
              <div className="bg-gradient-to-br from-secondary to-primary p-1 rounded-2xl shadow-xl">
                <div className="bg-white rounded-xl overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/8370764/pexels-photo-8370764.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" 
                    alt="Data visualization dashboard" 
                    className="w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-60 rounded-xl"></div>
                </div>
              </div>
              
              {/* Floating elements */}
              <motion.div 
                className="absolute -top-6 -right-6 bg-white p-4 rounded-lg shadow-lg"
                animate={{ y: [0, -10, 0] }}
                transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              >
                <div className="flex items-center space-x-2">
                  <Coins className="h-5 w-5 text-accent-dark" />
                  <div>
                    <p className="text-xs font-medium">Total Earnings</p>
                    <p className="text-sm font-bold">$1,240.85</p>
                  </div>
                </div>
              </motion.div>
              
              <motion.div 
                className="absolute -bottom-8 -left-8 bg-white p-4 rounded-lg shadow-lg"
                animate={{ y: [0, 10, 0] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut", delay: 0.5 }}
              >
                <div className="flex items-center space-x-2">
                  <Database className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs font-medium">Data Protected</p>
                    <p className="text-sm font-bold">56.7 GB</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;