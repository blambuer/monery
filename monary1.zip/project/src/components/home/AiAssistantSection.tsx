import React from 'react';
import { motion } from 'framer-motion';
import { Brain, TrendingUp, Sparkles, Bot } from 'lucide-react';
import Section from '../ui/Section';
import Animated from '../ui/Animated';

const AiAssistantSection: React.FC = () => {
  return (
    <Section
      id="ai-assistant"
      background="gradient"
      className="overflow-hidden"
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <Animated type="slide-in">
          <div>
            <h2 className="text-4xl font-bold mb-6 text-white">AI Optimizes Your Earnings</h2>
            <p className="text-lg text-white/80 mb-8">
              Our AI agents help you price, time, and manage your data assets to maximize your income.
            </p>
            
            <div className="space-y-6">
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
                <div className="flex items-start">
                  <div className="bg-accent rounded-full p-2 mr-4">
                    <TrendingUp className="h-5 w-5 text-gray-900" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">Market Intelligence</h3>
                    <p className="text-white/70">
                      Real-time market analysis to maximize your data's value based on current demand.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
                <div className="flex items-start">
                  <div className="bg-accent rounded-full p-2 mr-4">
                    <Brain className="h-5 w-5 text-gray-900" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">Personalized Strategy</h3>
                    <p className="text-white/70">
                      Custom recommendations based on your data portfolio and past performance.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm p-6 rounded-xl">
                <div className="flex items-start">
                  <div className="bg-accent rounded-full p-2 mr-4">
                    <Sparkles className="h-5 w-5 text-gray-900" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white mb-2">Profit Optimization</h3>
                    <p className="text-white/70">
                      Automated adjustments to help you earn 30% more than manual management.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Animated>
        
        <Animated type="fade" delay={0.3}>
          <div className="relative">
            <div className="absolute -top-16 -left-16 w-32 h-32 bg-accent opacity-20 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-16 -right-16 w-32 h-32 bg-blue-500 opacity-20 rounded-full blur-3xl"></div>
            
            <motion.div
              initial={{ y: 20 }}
              animate={{ y: [20, 0, 20] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              className="bg-white p-6 rounded-xl shadow-2xl relative z-10"
            >
              <div className="mb-6 flex justify-between items-center">
                <div className="flex items-center">
                  <div className="bg-primary rounded-full p-2 mr-3">
                    <Bot className="h-5 w-5 text-white" />
                  </div>
                  <h3 className="font-semibold">Monery AI Assistant</h3>
                </div>
                <span className="bg-green-100 text-green-600 text-xs px-2 py-1 rounded-full">Online</span>
              </div>
              
              <div className="space-y-4 mb-6">
                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                  <p className="text-sm">I've analyzed your data assets. Your browsing history data is in high demand right now.</p>
                </div>
                
                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                  <p className="text-sm">Recommendation: Increase your minimum bid by 15% to maximize revenue.</p>
                </div>
                
                <div className="bg-primary/10 rounded-lg p-3 max-w-[80%] ml-auto">
                  <p className="text-sm">How much extra can I earn with this change?</p>
                </div>
                
                <div className="bg-gray-100 rounded-lg p-3 max-w-[80%]">
                  <p className="text-sm">Based on current market trends, this adjustment would increase your monthly earnings by approximately $42.75.</p>
                </div>
              </div>
              
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Ask your AI assistant..." 
                  className="w-full p-3 pr-12 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
                <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-primary">
                  <Sparkles className="h-5 w-5" />
                </button>
              </div>
            </motion.div>
          </div>
        </Animated>
      </div>
    </Section>
  );
};

export default AiAssistantSection;