import React from 'react';
import { motion } from 'framer-motion';
import { Users, Target, Zap } from 'lucide-react';
import Section from '../ui/Section';
import Button from '../ui/Button';
import Animated from '../ui/Animated';

const AboutSection: React.FC = () => {
  return (
    <Section
      id="about"
      background="light"
      className="py-20"
    >
      <div className="max-w-3xl mx-auto text-center mb-16">
        <Animated type="slide-up">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Our Mission & Vision
          </h2>
        </Animated>
        <Animated type="slide-up" delay={0.1}>
          <p className="text-lg text-text-secondary">
            Monery exists to democratize access to the personal data economy.
            We envision a future where data rights are basic human rights, and every individual 
            benefits from the value they create online.
          </p>
        </Animated>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Animated type="fade" delay={0.1}>
          <div className="bg-white rounded-xl shadow-md p-8 text-center">
            <div className="bg-primary/10 p-4 rounded-full inline-flex mb-6">
              <Users className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-4">Empower Users</h3>
            <p className="text-text-secondary">
              We believe everyone deserves to control and profit from their digital identity.
            </p>
          </div>
        </Animated>

        <Animated type="fade" delay={0.2}>
          <div className="bg-white rounded-xl shadow-md p-8 text-center">
            <div className="bg-primary/10 p-4 rounded-full inline-flex mb-6">
              <Target className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-4">Redefine Privacy</h3>
            <p className="text-text-secondary">
              Privacy and monetization shouldn't be mutually exclusive. We're proving they can coexist.
            </p>
          </div>
        </Animated>

        <Animated type="fade" delay={0.3}>
          <div className="bg-white rounded-xl shadow-md p-8 text-center">
            <div className="bg-primary/10 p-4 rounded-full inline-flex mb-6">
              <Zap className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-4">Innovate Technology</h3>
            <p className="text-text-secondary">
              We're building the next generation of data infrastructure powered by AI and Web3.
            </p>
          </div>
        </Animated>
      </div>
    </Section>
  );
};

export default AboutSection;