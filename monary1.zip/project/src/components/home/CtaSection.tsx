import React from 'react';
import { ArrowRight, AppleIcon, Globe } from 'lucide-react';
import Section from '../ui/Section';
import Button from '../ui/Button';
import Animated from '../ui/Animated';

const CtaSection: React.FC = () => {
  return (
    <Section
      id="download"
      background="light"
      centered
      className="relative overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl"></div>
      
      <div className="relative z-10 py-16">
        <Animated type="slide-up">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-center">Ready to Own and Earn?</h2>
        </Animated>
        
        <Animated type="slide-up" delay={0.1}>
          <p className="text-lg md:text-xl text-text-secondary max-w-2xl mx-auto text-center mb-12">
            Start now and take control of your data. Our easy-to-use apps make monetization simple and secure.
          </p>
        </Animated>
        
        <Animated type="fade" delay={0.2}>
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
            <Button 
              variant="primary" 
              size="lg"
              className="flex items-center justify-center"
              href="/app"
            >
              <AppleIcon className="mr-2 h-5 w-5" />
              Download for iOS
            </Button>
            
            <Button 
              variant="secondary" 
              size="lg"
              className="flex items-center justify-center"
              href="/app"
            >
              <svg className="mr-2 h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.523 15.341l.801 1.38c.269.473.854.608 1.308.301a9.97 9.97 0 0 0 4.367-8.315C24 3.917 19.075 0 13.23 0c-2.798 0-5.373.945-7.434 2.531a1 1 0 0 0-.118 1.5l10.074 11.312c.433.487 1.169.386 1.498 0M1.633 3.169a1 1 0 0 0-1.498.132A12.138 12.138 0 0 0 0 9.702c0 4.453 2.501 8.32 6.182 10.437.411.235.931.15 1.199-.189l.863-1.432c.342-.57.034-1.008-.138-1.216L2.371 4.236c-.18-.215-.45-.337-.738-.337h0M13.416 24c3.167 0 5.738-2.556 5.738-5.702 0-1.595-.651-3.035-1.695-4.081L10.83 7.32c-.55-.555-1.503-.159-1.503.625v10.353c0 3.146 2.66 5.702 5.826 5.702h0"/>
              </svg>
              Download for Android
            </Button>
            
            <Button 
              variant="accent" 
              size="lg"
              className="flex items-center justify-center"
              href="/app"
            >
              <Globe className="mr-2 h-5 w-5" />
              Chrome Web Store
            </Button>
          </div>
        </Animated>
        
        <Animated type="fade" delay={0.3}>
          <p className="text-center text-text-secondary">
            Start now, it takes less than 1 minute!
          </p>
        </Animated>
        
        <Animated type="slide-up" delay={0.4} className="mt-16">
          <div className="bg-gradient-to-r from-primary to-secondary p-8 md:p-12 rounded-2xl text-white text-center">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">Stay Updated. Join the Revolution.</h3>
            <p className="max-w-xl mx-auto mb-8">
              Be the first to know about new features, updates, and special offers.
            </p>
            
            <div className="flex flex-col sm:flex-row max-w-md mx-auto">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-grow px-4 py-3 rounded-l-md sm:rounded-r-none rounded-r-md sm:mb-0 mb-3 text-text-primary focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <Button 
                variant="accent"
                className="rounded-l-none sm:rounded-l-none rounded-l-md text-text-primary"
              >
                Subscribe <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </Animated>
      </div>
    </Section>
  );
};

export default CtaSection;