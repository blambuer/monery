import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Database, DollarSign, ArrowRight } from 'lucide-react';
import Section from '../ui/Section';
import Animated from '../ui/Animated';

const HowItWorksSection: React.FC = () => {
  const steps = [
    {
      icon: <Database />,
      title: 'Collect',
      description: 'Install our plugin/app to start securing your data privately.',
      delay: 0.1,
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: <Shield />,
      title: 'Tokenize',
      description: 'Convert your data into encrypted, tradable assets.',
      delay: 0.2,
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: <DollarSign />,
      title: 'Monetize',
      description: 'Earn directly by selling or staking your data.',
      delay: 0.3,
      color: 'from-yellow-500 to-yellow-600'
    }
  ];

  return (
    <Section
      id="how-it-works"
      title="How Monery Empowers You"
      subtitle="Our platform makes data monetization simple, secure, and profitable in just three easy steps."
      centered
      background="dark"
      className="relative overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-1/2 bg-secondary opacity-10 rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/4"></div>
        <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-primary opacity-10 rounded-full blur-3xl transform -translate-x-1/3 translate-y-1/4"></div>
      </div>

      <div className="relative z-10 mt-16">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 md:gap-4">
          {steps.map((step, index) => (
            <React.Fragment key={index}>
              <Animated
                type="slide-up"
                delay={step.delay}
                className="w-full md:w-1/3 flex flex-col items-center text-center"
              >
                <div className={`bg-gradient-to-r ${step.color} rounded-full p-6 mb-6`}>
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
                    className="text-white w-12 h-12"
                  >
                    {step.icon}
                  </motion.div>
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">{step.title}</h3>
                <p className="text-gray-300">{step.description}</p>
              </Animated>

              {index < steps.length - 1 && (
                <div className="hidden md:flex text-gray-500">
                  <ArrowRight size={32} />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>

        <Animated type="fade" delay={0.5} className="mt-16 text-center">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-block"
          >
            <a
              href="/how-it-works"
              className="inline-flex items-center bg-white text-gray-900 py-3 px-8 rounded-md font-medium hover:bg-gray-100 transition-colors"
            >
              Learn More
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </motion.div>
        </Animated>
      </div>
    </Section>
  );
};

export default HowItWorksSection;