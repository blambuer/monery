import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Tag, ShieldCheck } from 'lucide-react';
import Section from '../ui/Section';
import Button from '../ui/Button';
import Animated from '../ui/Animated';

const MarketplaceSection: React.FC = () => {
  const marketplaceItems = [
    {
      type: 'Social Activity',
      minBid: '$75',
      privacyLevel: 'High',
      image: 'https://images.pexels.com/photos/935979/pexels-photo-935979.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      delay: 0.1
    },
    {
      type: 'Browsing History',
      minBid: '$120',
      privacyLevel: 'Maximum',
      image: 'https://images.pexels.com/photos/920382/pexels-photo-920382.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      delay: 0.2
    },
    {
      type: 'Fitness Data',
      minBid: '$60',
      privacyLevel: 'Medium',
      image: 'https://images.pexels.com/photos/3761012/pexels-photo-3761012.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      delay: 0.3
    }
  ];

  return (
    <Section
      id="marketplace"
      title="Explore The Monery Marketplace"
      subtitle="Preview our decentralized marketplace where your data becomes a valuable asset."
      centered
      background="light"
    >
      <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {marketplaceItems.map((item, index) => (
          <Animated key={index} type="fade" delay={item.delay}>
            <motion.div
              whileHover={{ y: -10 }}
              className="overflow-hidden rounded-xl shadow-lg bg-white"
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.type} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">{item.type}</h3>
                  <div className="bg-accent/20 text-accent-dark rounded-full px-3 py-1 text-sm font-medium">
                    {item.minBid}
                  </div>
                </div>
                <div className="flex justify-between text-sm text-gray-500">
                  <div className="flex items-center">
                    <Tag className="h-4 w-4 mr-1" />
                    <span>Data Token</span>
                  </div>
                  <div className="flex items-center">
                    <ShieldCheck className="h-4 w-4 mr-1" />
                    <span>{item.privacyLevel} Privacy</span>
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-center">
                  <div className="flex items-center text-sm text-green-600">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    <span>High Demand</span>
                  </div>
                  <Button variant="text" size="sm" href="/marketplace">
                    View Details
                  </Button>
                </div>
              </div>
            </motion.div>
          </Animated>
        ))}
      </div>
      
      <div className="mt-12 text-center">
        <Button variant="primary" size="lg" href="/marketplace">
          Explore Marketplace
        </Button>
      </div>
    </Section>
  );
};

export default MarketplaceSection;