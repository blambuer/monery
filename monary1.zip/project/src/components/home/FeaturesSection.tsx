import React from 'react';
import { Shield, Database, ShoppingCart, Brain, Lock } from 'lucide-react';
import Card from '../ui/Card';
import Section from '../ui/Section';
import Animated from '../ui/Animated';

const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: <Database className="h-8 w-8 text-primary" />,
      title: 'Personal Data Vault',
      description: 'Monery\'s encrypted vault ensures your browsing history, social interactions, and activities are secured and fully owned by you.',
      delay: 0
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: 'Data Tokenization',
      description: 'Convert different types of your data into NFTs or SFTs, selectively choose what to monetize while maintaining full control.',
      delay: 0.1
    },
    {
      icon: <ShoppingCart className="h-8 w-8 text-primary" />,
      title: 'Data Marketplace',
      description: 'Access a decentralized marketplace where brands, researchers, and projects can offer to buy your data — transparently and fairly.',
      delay: 0.2
    },
    {
      icon: <Brain className="h-8 w-8 text-primary" />,
      title: 'AI-Powered Insights',
      description: 'Let our AI advisors recommend the best monetization strategies, predict the value of your data assets, and help you earn more.',
      delay: 0.3
    },
    {
      icon: <Lock className="h-8 w-8 text-primary" />,
      title: 'Full Privacy Control',
      description: 'Using zk-SNARK-like privacy protections, Monery ensures your identity and sensitive information are never exposed.',
      delay: 0.4
    }
  ];

  return (
    <Section
      id="features"
      title="Features That Put You in Control"
      subtitle="Monery provides everything you need to securely manage, tokenize, and monetize your personal data."
      centered
      background="light"
    >
      <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <Animated key={index} type="fade" delay={feature.delay}>
            <Card className="h-full flex flex-col">
              <div className="rounded-full bg-primary/10 p-4 inline-block mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-text-secondary flex-grow">{feature.description}</p>
            </Card>
          </Animated>
        ))}
      </div>
    </Section>
  );
};

export default FeaturesSection;