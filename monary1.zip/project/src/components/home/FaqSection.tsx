import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';
import Section from '../ui/Section';
import Animated from '../ui/Animated';

const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: 'What is Monery and how does it help me earn?',
      answer: 'Monery is a platform that enables you to collect, tokenize, and monetize your personal data while maintaining complete privacy and control. It transforms your digital footprint into valuable assets that can generate income through our marketplace.'
    },
    {
      question: 'Is my data visible to others?',
      answer: 'No. All your data is encrypted and stored securely. Only the specific data you choose to sell or share is made available to buyers, and even then, it\'s anonymized using zero-knowledge technology to protect your identity.'
    },
    {
      question: 'Who can purchase my tokenized data?',
      answer: 'Researchers, advertisers, AI development projects, and data analytics firms can request data through our secure marketplace. All buyers are verified and must adhere to strict usage guidelines to ensure ethical data practices.'
    },
    {
      question: 'How much can I earn with Monery?',
      answer: 'Earnings vary based on the type, quantity, and quality of data you provide. Some users earn a few dollars monthly, while power users with valuable data sets can earn hundreds or even thousands of dollars.'
    }
  ];

  return (
    <Section
      id="faq"
      background="light"
      className="py-20"
    >
      <div className="max-w-3xl mx-auto">
        <Animated type="slide-up">
          <h2 className="text-3xl font-bold text-center mb-12">
            Frequently Asked Questions
          </h2>
        </Animated>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <Animated key={index} type="fade" delay={index * 0.1}>
              <div className="bg-white rounded-xl shadow-md overflow-hidden">
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full flex justify-between items-center p-6 text-left"
                >
                  <h3 className="text-lg font-semibold">{faq.question}</h3>
                  {openIndex === index ? (
                    <ChevronUp className="h-5 w-5 text-primary flex-shrink-0" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-400 flex-shrink-0" />
                  )}
                </button>
                <AnimatePresence>
                  {openIndex === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="p-6 pt-0 border-t border-gray-100">
                        <p className="text-text-secondary">{faq.answer}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </Animated>
          ))}
        </div>
      </div>
    </Section>
  );
};

export default FaqSection;