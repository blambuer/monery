import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, DollarSign } from 'lucide-react';
import * as Progress from '@radix-ui/react-progress';

interface StatsCardProps {
  totalEarnings: string;
  activeListings: number;
  referralCount: number;
}

const StatsCard: React.FC<StatsCardProps> = ({
  totalEarnings,
  activeListings,
  referralCount
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <motion.div
        whileHover={{ scale: 1.02 }}
        className="bg-gradient-to-r from-primary to-primary-dark p-6 rounded-xl text-white"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Total Earnings</h3>
          <DollarSign className="h-6 w-6 opacity-80" />
        </div>
        <p className="text-3xl font-bold mb-2">{totalEarnings} MON</p>
        <div className="flex items-center text-white/80">
          <TrendingUp className="h-4 w-4 mr-1" />
          <span>+12.5% this month</span>
        </div>
      </motion.div>

      <motion.div
        whileHover={{ scale: 1.02 }}
        className="bg-white p-6 rounded-xl shadow-lg"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Active Listings</h3>
          <div className="bg-primary/10 p-2 rounded-full">
            <TrendingUp className="h-5 w-5 text-primary" />
          </div>
        </div>
        <p className="text-3xl font-bold mb-2">{activeListings}</p>
        <Progress.Root className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <Progress.Indicator
            className="h-full bg-primary transition-transform duration-500"
            style={{ transform: `translateX(-${100 - (activeListings / 10) * 100}%)` }}
          />
        </Progress.Root>
      </motion.div>

      <motion.div
        whileHover={{ scale: 1.02 }}
        className="bg-white p-6 rounded-xl shadow-lg"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Total Referrals</h3>
          <div className="bg-primary/10 p-2 rounded-full">
            <Users className="h-5 w-5 text-primary" />
          </div>
        </div>
        <p className="text-3xl font-bold mb-2">{referralCount}</p>
        <div className="flex items-center text-green-600">
          <TrendingUp className="h-4 w-4 mr-1" />
          <span>+3 this week</span>
        </div>
      </motion.div>
    </div>
  );
};

export default StatsCard;