import React from 'react';
import { useAccount, useWalletClient, usePublicClient } from 'wagmi';
import { toast } from 'react-hot-toast';
import { formatEther, parseEther } from 'viem';
import { buyDataToken } from '../../lib/contracts/MarketplaceContract';
import Button from '../ui/Button';

interface ListingCardProps {
  id: string;
  tokenId: number;
  name: string;
  description: string;
  category: string;
  price: string;
  seller: string;
  onPurchase?: () => void;
}

const ListingCard: React.FC<ListingCardProps> = ({
  id,
  tokenId,
  name,
  description,
  category,
  price,
  seller,
  onPurchase
}) => {
  const { address } = useAccount();
  const { data: walletClient } = useWalletClient();
  const publicClient = usePublicClient();

  const handleBuy = async () => {
    if (!address || !walletClient || !publicClient) {
      toast.error('Please connect your wallet first');
      return;
    }

    try {
      toast.loading('Processing purchase...');
      const priceInWei = parseEther(price);
      
      const hash = await buyDataToken(
        walletClient,
        publicClient,
        tokenId,
        priceInWei
      );

      await publicClient.waitForTransactionReceipt({ hash });

      toast.dismiss();
      toast.success('Purchase successful!');
      onPurchase?.();
    } catch (error: any) {
      console.error('Purchase error:', error);
      toast.dismiss();
      toast.error(error.message || 'Failed to purchase token');
    }
  };

  const isOwner = address?.toLowerCase() === seller.toLowerCase();

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-lg font-semibold mb-1">{name}</h3>
            <p className="text-sm text-gray-500 capitalize">{category}</p>
          </div>
          <div className="bg-primary/10 px-3 py-1 rounded-full">
            <span className="text-primary font-medium">{price} MON</span>
          </div>
        </div>
        
        <p className="text-gray-600 mb-4 line-clamp-2">{description}</p>
        
        <div className="flex justify-between items-center">
          <div className="text-sm text-gray-500">
            ID: {tokenId}
          </div>
          <Button
            variant="primary"
            size="sm"
            onClick={handleBuy}
            disabled={isOwner}
          >
            {isOwner ? 'Your Token' : 'Buy Now'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ListingCard;