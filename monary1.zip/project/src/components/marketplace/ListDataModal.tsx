import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useWalletClient, usePublicClient } from 'wagmi';
import { parseEther } from 'viem';
import { toast } from 'react-hot-toast';
import { X } from 'lucide-react';
import { listDataToken } from '../../lib/contracts/MarketplaceContract';
import Button from '../ui/Button';

const formSchema = z.object({
  tokenId: z.number().min(1, 'Token ID is required'),
  price: z.string().min(1, 'Price is required')
});

type FormData = z.infer<typeof formSchema>;

interface ListDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

const ListDataModal: React.FC<ListDataModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { data: walletClient } = useWalletClient();
  const publicClient = usePublicClient();
  
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(formSchema)
  });

  const onSubmit = async (data: FormData) => {
    if (!walletClient || !publicClient) {
      toast.error('Please connect your wallet first');
      return;
    }

    try {
      toast.loading('Listing token...');
      const priceInWei = parseEther(data.price);
      
      const hash = await listDataToken(
        walletClient,
        publicClient,
        data.tokenId,
        priceInWei
      );

      await publicClient.waitForTransactionReceipt({ hash });

      toast.dismiss();
      toast.success('Token listed successfully!');
      onSuccess?.();
      onClose();
    } catch (error: any) {
      console.error('Listing error:', error);
      toast.dismiss();
      toast.error(error.message || 'Failed to list token');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">List Data Token</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Token ID
            </label>
            <input
              type="number"
              {...register('tokenId', { valueAsNumber: true })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Enter token ID"
            />
            {errors.tokenId && (
              <p className="mt-1 text-sm text-red-600">{errors.tokenId.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Price (MON)
            </label>
            <input
              type="text"
              {...register('price')}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Enter price in MON"
            />
            {errors.price && (
              <p className="mt-1 text-sm text-red-600">{errors.price.message}</p>
            )}
          </div>

          <div className="flex justify-end space-x-4 pt-4">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" type="submit">
              List Token
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ListDataModal;