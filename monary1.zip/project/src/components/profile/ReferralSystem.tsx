import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Share2, Copy, Check, Gift, ExternalLink } from 'lucide-react';
import { useUserStore } from '../../lib/store';
import Card from '../ui/Card';
import Button from '../ui/Button';

const ReferralSystem: React.FC = () => {
  const { referralCode, referralCount } = useUserStore();
  const [copied, setCopied] = useState(false);
  
  const handleCopy = async () => {
    if (referralCode) {
      await navigator.clipboard.writeText(
        `${window.location.origin}/signup?ref=${referralCode}`
      );
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };
  
  const shareReferral = async () => {
    if (navigator.share && referralCode) {
      try {
        await navigator.share({
          title: 'Join Monery',
          text: 'Start earning from your data with Monery! Use my referral link to get bonus rewards.',
          url: `${window.location.origin}/signup?ref=${referralCode}`,
        });
      } catch (err) {
        console.error('Error sharing:', err);
      }
    }
  };

  const rewards = [
    {
      title: 'Sign Up Bonus',
      description: '5 Monery Points for you and your friend',
      icon: <Gift className="h-5 w-5" />
    },
    {
      title: 'First Sale Bonus',
      description: '10% commission on their first data sale',
      icon: <Coins className="h-5 w-5" />
    },
    {
      title: 'Referral Badge',
      description: 'Special badge after 5 successful referrals',
      icon: <Award className="h-5 w-5" />
    }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Your Referral Link</h3>
            <Button 
              variant="outline" 
              size="sm"
              onClick={shareReferral}
              className="flex items-center"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
          </div>
          
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={`${window.location.origin}/signup?ref=${referralCode}`}
              className="flex-grow px-4 py-2 bg-gray-50 rounded-lg text-sm font-mono"
              readOnly
            />
            <Button
              variant="primary"
              onClick={handleCopy}
              className="flex items-center"
            >
              {copied ? (
                <Check className="h-4 w-4" />
              ) : (
                <Copy className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </Card>

      <Card>
        <h3 className="text-lg font-semibold mb-4">Referral Rewards</h3>
        <div className="space-y-4">
          {rewards.map((reward, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg"
            >
              <div className="rounded-full p-2 bg-primary/10 text-primary">
                {reward.icon}
              </div>
              <div>
                <h4 className="font-medium">{reward.title}</h4>
                <p className="text-sm text-gray-600">{reward.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Your Impact</h3>
          <span className="text-sm text-gray-500">
            {referralCount} friends joined
          </span>
        </div>
        <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min((referralCount / 5) * 100, 100)}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="absolute top-0 left-0 h-full bg-primary rounded-full"
          />
        </div>
        <p className="text-sm text-gray-500 mt-2">
          {referralCount >= 5 ? (
            'Congratulations! You\'ve earned the Referral King badge!'
          ) : (
            `${5 - referralCount} more referrals until you earn the Referral King badge`
          )}
        </p>
      </Card>
    </div>
  );
};

export default ReferralSystem;