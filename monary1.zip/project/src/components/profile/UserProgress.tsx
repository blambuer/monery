import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Users, Star, Award, Calendar } from 'lucide-react';
import { useUserStore } from '../../lib/store';
import Card from '../ui/Card';

const UserProgress: React.FC = () => {
  const { xp, level, badges, referralCount, dailyLoginStreak } = useUserStore();
  
  const levelProgress = (xp % 1000) / 1000 * 100;
  
  return (
    <div className="space-y-6">
      {/* Level Progress */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Trophy className="h-6 w-6 text-primary mr-2" />
            <h3 className="text-lg font-semibold">Level {level}</h3>
          </div>
          <span className="text-sm text-gray-500">{xp} XP</span>
        </div>
        <motion.div 
          className="w-full h-2 bg-gray-200 rounded-full overflow-hidden"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div 
            className="h-full bg-primary rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${levelProgress}%` }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        </motion.div>
        <p className="text-sm text-gray-500 mt-2">
          {1000 - (xp % 1000)} XP until next level
        </p>
      </Card>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Daily Streak */}
        <Card>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Calendar className="h-6 w-6 text-primary mr-2" />
              <h3 className="text-lg font-semibold">Daily Streak</h3>
            </div>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, type: "spring" }}
              className="bg-primary/10 px-3 py-1 rounded-full"
            >
              <span className="text-primary font-bold">{dailyLoginStreak} days</span>
            </motion.div>
          </div>
        </Card>

        {/* Referrals */}
        <Card>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Users className="h-6 w-6 text-primary mr-2" />
              <h3 className="text-lg font-semibold">Referrals</h3>
            </div>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, type: "spring", delay: 0.1 }}
              className="bg-primary/10 px-3 py-1 rounded-full"
            >
              <span className="text-primary font-bold">{referralCount}</span>
            </motion.div>
          </div>
        </Card>
      </div>
      
      {/* Badges */}
      <Card>
        <div className="flex items-center mb-4">
          <Award className="h-6 w-6 text-primary mr-2" />
          <h3 className="text-lg font-semibold">Earned Badges</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {badges.map((badge, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-center p-3 bg-gray-50 rounded-lg"
            >
              <Star className="h-5 w-5 text-accent mr-2" />
              <span className="text-sm font-medium">{badge}</span>
            </motion.div>
          ))}
          {badges.length === 0 && (
            <p className="text-sm text-gray-500 col-span-full text-center py-4">
              Complete achievements to earn badges!
            </p>
          )}
        </div>
      </Card>
    </div>
  );
};

export default UserProgress;