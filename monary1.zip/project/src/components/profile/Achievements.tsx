import React from 'react';
import { motion } from 'framer-motion';
import { Star, Shield, Zap, Award } from 'lucide-react';
import Card from '../ui/Card';

interface Achievement {
  icon: React.ReactNode;
  title: string;
  description: string;
  progress: number;
  reward: string;
}

const achievements: Achievement[] = [
  {
    icon: <Star className="h-6 w-6" />,
    title: 'Data Pioneer',
    description: 'Complete your first data tokenization',
    progress: 0,
    reward: '50 XP'
  },
  {
    icon: <Shield className="h-6 w-6" />,
    title: 'Privacy Guardian',
    description: 'Set up all privacy controls',
    progress: 75,
    reward: '100 XP'
  },
  {
    icon: <Zap className="h-6 w-6" />,
    title: 'Quick Learner',
    description: 'Complete the platform tutorial',
    progress: 100,
    reward: '75 XP'
  },
  {
    icon: <Award className="h-6 w-6" />,
    title: 'Community Leader',
    description: 'Refer 5 friends to Monery',
    progress: 40,
    reward: '200 XP'
  }
];

const Achievements: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {achievements.map((achievement, index) => (
        <Card key={index} className="relative overflow-hidden">
          <div className="flex items-start space-x-4">
            <div className="rounded-full p-3 bg-primary/10 text-primary">
              {achievement.icon}
            </div>
            
            <div className="flex-grow">
              <h3 className="font-semibold mb-1">{achievement.title}</h3>
              <p className="text-sm text-gray-500 mb-3">{achievement.description}</p>
              
              <div className="relative h-2 bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${achievement.progress}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="absolute top-0 left-0 h-full bg-primary rounded-full"
                />
              </div>
              
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-500">
                  {achievement.progress}% Complete
                </span>
                <span className="text-sm font-medium text-primary">
                  {achievement.reward}
                </span>
              </div>
            </div>
          </div>
          
          {achievement.progress === 100 && (
            <div className="absolute top-2 right-2">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5, type: "spring" }}
              >
                <Award className="h-6 w-6 text-accent" />
              </motion.div>
            </div>
          )}
        </Card>
      ))}
    </div>
  );
};

export default Achievements;