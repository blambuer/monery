import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Gift, Users } from 'lucide-react';
import Button from '../ui/Button';
import { useWeb3Store } from '../../lib/store';
import { getReferralRewards } from '../../lib/contracts/ReferralContract';

const ReferralCard: React.FC = () => {
  const { account, provider } = useWeb3Store();
  const [rewards, setRewards] = useState('0');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (provider && account) {
      fetchRewards();
    }
  }, [provider, account]);

  const fetchRewards = async () => {
    if (!provider || !account) return;
    try {
      const rewards = await getReferralRewards(provider, account);
      setRewards(rewards);
    } catch (error) {
      console.error('Error fetching rewards:', error);
    }
  };

  const referralLink = account 
    ? `${window.location.origin}?ref=${account}`
    : '';

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold">Referral Program</h3>
        <div className="bg-primary/10 p-2 rounded-full">
          <Users className="h-6 w-6 text-primary" />
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-600 mb-2">
            Your Referral Link
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={referralLink}
              readOnly
              className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 text-sm"
            />
            <Button
              variant="outline"
              onClick={copyReferralLink}
              className="flex items-center"
            >
              <Copy className="h-4 w-4 mr-2" />
              {copied ? 'Copied!' : 'Copy'}
            </Button>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Available Rewards</p>
              <p className="text-2xl font-bold text-primary">{rewards} MON</p>
            </div>
            <div className="bg-primary/10 p-3 rounded-full">
              <Gift className="h-6 w-6 text-primary" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="bg-primary/5 rounded-lg p-4"
          >
            <p className="text-sm text-gray-600">Total Referrals</p>
            <p className="text-xl font-semibold">12</p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            className="bg-primary/5 rounded-lg p-4"
          >
            <p className="text-sm text-gray-600">Total Earned</p>
            <p className="text-xl font-semibold">240 MON</p>
          </motion.div>
        </div>

        <Button variant="primary" className="w-full">
          Claim Rewards
        </Button>
      </div>
    </div>
  );
};

export default ReferralCard;