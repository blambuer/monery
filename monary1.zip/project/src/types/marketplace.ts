export interface DataListing {
  id: number;
  seller: string;
  amount: bigint;
  price: bigint;
  category: string;
  active: boolean;
  timestamp: number;
}